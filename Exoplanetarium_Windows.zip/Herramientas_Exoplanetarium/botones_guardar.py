import tkinter as tk
from tkinter import filedialog
from tkinter import Button
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter
from matplotlib.animation import FFMpegWriter
from tkinter import filedialog, Button, Frame


def guardar_grafico(fig, formato):
    filetypes = {
        "png": [("PNG files", "*.png")],
        "jpeg": [("JPEG files", "*.jpeg")],
        "pdf": [("PDF files", "*.pdf")]
    }
    # Obtener los tipos de archivos correspondientes al formato seleccionado
    selected_filetypes = filetypes.get(formato, [("All files", "*.*")])
    # Mostrar el cuadro de diálogo para guardar el archivo
    file_path = filedialog.asksaveasfilename(defaultextension=f".{formato}", filetypes=selected_filetypes)
    if file_path:
        fig.savefig(file_path)

def crear_botones_guardar(ventana, fig):
    frame_botones = tk.Frame(ventana, bg="gray26")
    frame_botones.pack(side=tk.BOTTOM, pady=10)

    btn_guardar_png = Button(frame_botones, text="Guardar como PNG", command=lambda: guardar_grafico(fig, "png"), bg="#7c37ac")
    btn_guardar_png.pack(side=tk.LEFT, padx=5)

    btn_guardar_jpeg = Button(frame_botones, text="Guardar como JPEG", command=lambda: guardar_grafico(fig, "jpeg"), bg="#7c37ac")
    btn_guardar_jpeg.pack(side=tk.LEFT, padx=5)

    btn_guardar_pdf = Button(frame_botones, text="Guardar como PDF", command=lambda: guardar_grafico(fig, "pdf"), bg="#7c37ac")
    btn_guardar_pdf.pack(side=tk.LEFT, padx=5)

    return frame_botones


def guardar_simulacion(anim, formato):
    filetypes = {
        "gif": [("GIF files", "*.gif")],
        "mp4": [("MP4 files", "*.mp4")]
    }
    selected_filetypes = filetypes.get(formato, [("All files", "*.*")])
    file_path = filedialog.asksaveasfilename(defaultextension=f".{formato}", filetypes=selected_filetypes)
    if file_path:
        if formato == "gif":
            anim.save(file_path, writer=PillowWriter(fps=10))
        elif formato == "mp4":
            anim.save(file_path, writer=FFMpegWriter(fps=10))

def botones_guardar_simulacion(ventana, anim):
    frame_botones = Frame(ventana, bg="gray26")
    frame_botones.pack(side="bottom", pady=10)

    btn_guardar_gif = Button(frame_botones, text="Guardar como GIF", command=lambda: guardar_simulacion(anim, "gif"), bg="#7c37ac")
    btn_guardar_gif.pack(side="left", padx=5)

    btn_guardar_mp4 = Button(frame_botones, text="Guardar como MP4", command=lambda: guardar_simulacion(anim, "mp4"), bg="#7c37ac")
    btn_guardar_mp4.pack(side="left", padx=5)

    return frame_botones