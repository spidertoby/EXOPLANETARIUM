import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter as tk
from tkinter import messagebox, Toplevel

def plot_scatter(root, datos, x_param_es, y_param_es, param_map_es_to_en, color_param_es, mostrar_temperatura):
    """
    Esta función crea un gráfico de dispersión entre dos parámetros que el usuario selecciona, con la opción de colorear 
    los puntos si es que se selecciona la opción de temperatura superficial. Finalmente, este gráfico se muestra en una 
    ventana emergente de Tkinter.

    Parámetros:
    - root (tk.Tk): Ventana principal de Tkinter desde la cual se abrirá la ventana emergente.
    - datos (pandas.DataFrame): DataFrame que contiene los datos a graficar, incluyendo las columnas de los parámetros 
        seleccionados y, opcionalmente, la temperatura superficial.
    - x_param_es (str): Nombre del parámetro para el eje X (en español).
    - y_param_es (str): Nombre del parámetro para el eje Y (en español).
    - param_map_es_to_en (dict): Diccionario que mapea los nombres de los parámetros en español a sus nombres en inglés.
    - mostrar_temperatura (bool): Indica si se debe colorear los puntos del gráfico según la temperatura superficial de los planetas.

    Salida:
    - None

    Excepciones:
    - KeyError: Si alguno de los parámetros seleccionados no se encuentra en los datos.
    """
    #Convertimos los nombres de los parámetros en español a los nombres del catálogo en inglés   
    x_param = param_map_es_to_en.get(x_param_es)
    y_param = param_map_es_to_en.get(y_param_es)
    color_param = param_map_es_to_en.get(color_param_es)
    
    if x_param and y_param and color_param:
        try:
            print(f"Parámetro X seleccionado: {x_param}")
            print(f"Parámetro Y seleccionado: {y_param}")
            print(f"Parámetro de Color seleccionado: {color_param}")
            
            #Creamos una nueva ventana para mostrar el gráfico
            popup = Toplevel(root)
            popup.title("Scatter Plot")
            popup.configure(bg="gray26")
            
            num_planetas = len(datos[x_param]) #Número de planetas en el eje X
            
            fig, ax = plt.subplots() #Creamos una figura y un eje
            
            # Determinamos la variable para colorear los puntos
            color_data = datos[color_param]


            #Coloreamos los puntos según la temperatura
            scatter = ax.scatter(datos[x_param], datos[y_param], c=color_data, cmap='viridis', alpha=0.7)
            cbar = plt.colorbar(scatter)
            cbar.set_label(color_param_es)
            
            ax.set_xlabel(x_param_es)
            ax.set_ylabel(y_param_es)
            ax.set_title(f"Scatter Plot de {x_param_es} vs {y_param_es}")
            
            #Se agregan el número total de planetas que fueron graficados
            ax.text(0.98, 0.98, f"Total planetas: {num_planetas}", transform=ax.transAxes, horizontalalignment='right', verticalalignment='top', fontsize=10, bbox=dict(facecolor='white', alpha=0.5))
            
            #Se ajusta el diseño del gráfico y el color del fondo
            fig.patch.set_facecolor('beige')
            ax.set_facecolor('beige')
            fig.tight_layout()
            
            #Creamos finalmente un canvas para mostrar el gráfico en la ventana emergente, ajustando el tamaño de esta
            canvas = FigureCanvasTkAgg(fig, master=popup)
            canvas.draw()
            canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
            
            width, height = fig.get_size_inches() * fig.get_dpi()
            popup.geometry(f"{int(width)}x{int(height)}")
        #Mensaje de error si no se encuentra alguna de las columnas seleccionadas
        except KeyError as e:
            messagebox.showerror("Error", f"Columna no encontrada: {e}")
    else:
        messagebox.showerror("Error", "Por favor, seleccione ambos parámetros para los ejes.")
