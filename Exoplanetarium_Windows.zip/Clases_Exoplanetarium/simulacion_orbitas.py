import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter as tk
from tkinter import Button, Label, messagebox, filedialog, ttk, Toplevel, Checkbutton, IntVar
from Herramientas_Exoplanetarium.botones_guardar import guardar_simulacion, botones_guardar_simulacion


def datos_orbita_sistema(datos, star_name):
    """Función que obtiene los datos de los planetas que orbitan alrededor de una estrella específica.

    Args:
        datos (list): Objeto de tipo list que representa los datos de los planetas.
        star_name (list): Objeto de tipo list que representa el nombre de la estrella.

    Returns:
        string: Objeto de tipo string que representa los datos de los planetas que orbitan alrededor de una estrella específica.
    """
    star_planets = datos[datos['star_name'] == star_name]
    return star_planets

def calcular_orbita(semi_major_axis, eccentricity, omega, tperi, T, num=100):
    """Función que calcula la órbita de un planeta en coordenadas cartesianas.

    Args:
        semi_major_axis (float): Objeto de tipo float que representa el semieje mayor.
        eccentricity (float): Objeto de tipo float que representa la excentricidad.
        omega (float): Objeto de tipo float que representa el argumento del periastro.
        tperi (float): Objeto de tipo float que representa el tiempo en el periastro.
        T (float): Objeto de tipo float que representa el período orbital.
        num (int): Objeto de tipo int que representa el número de puntos a calcular.

    Returns:
        float: Ejes X y Y de la órbita del planeta.
    """
    omega_rad = np.radians(omega)
    t = np.linspace(0, T, num)
    M = 2 * np.pi * (t - tperi) / T
    E = M.copy()
    for _ in range(100):
        E = M + eccentricity * np.sin(E)
    x = semi_major_axis * (np.cos(E) - eccentricity)
    y = semi_major_axis * np.sqrt(1 - eccentricity**2) * np.sin(E)
    x_rot = x * np.cos(omega_rad) - y * np.sin(omega_rad)
    y_rot = x * np.sin(omega_rad) + y * np.cos(omega_rad)
    return x_rot, y_rot

def calcular_baricentro(datos, star_name):
    """Función que calcula el baricentro de un sistema planetario.

    Args:
        datos (var): Objeto de tipo var que representa los datos de los planetas.
        star_name (string): Objeto de tipo string que representa el nombre de la estrella.

    Returns:
        float: Ejes X y Y del baricentro del sistema planetario.
    """
    star_planets = datos_orbita_sistema(datos, star_name)
    star_mass = star_planets.iloc[0]['star_mass']
    total_mass = star_mass + star_planets['mass'].sum()
    x_pos, y_pos = 0, 0
    for _, planet in star_planets.iterrows():
        semi_major_axis = planet['semi_major_axis']
        eccentricity = planet['eccentricity']
        omega = planet['omega']
        tperi = planet['tperi']
        planet_mass = planet['mass']
        distance_to_periapsis = semi_major_axis * (1 - eccentricity)
        x_orbit = distance_to_periapsis * np.cos(np.radians(omega))
        y_orbit = distance_to_periapsis * np.sin(np.radians(omega))
        x_pos += x_orbit * planet_mass
        y_pos += y_orbit * planet_mass
    x_pos /= total_mass
    y_pos /= total_mass
    return x_pos, y_pos
    
def calcular_posicion_estrella(datos, star_name):
    """Función que calcula la posición de una estrella en un sistema planetario.

    Args:
        datos (var): Objeto de tipo var que representa los datos de los planetas.
        star_name (string): Objeto de tipo string que representa el nombre de la estrella.

    Returns:
        float: Valores mínimos y máximos de los ejes X y Y de la órbita.
    """
    baricentro_x, baricentro_y = calcular_baricentro(datos, star_name)
    star_planets = datos_orbita_sistema(datos, star_name)
    star_mass = star_planets.iloc[0]['star_mass']
    total_mass = star_mass + star_planets['mass'].sum()
    star_x = -baricentro_x * (star_mass / total_mass)
    star_y = -baricentro_y * (star_mass / total_mass)
    return star_x, star_y

def obtener_limites_orbita(datos, star_name):
    """Función que obtiene los límites de la órbita de un sistema planetario.

    Args:
        datos (var): Objeto de tipo var que representa los datos de los planetas.
        star_name (string): Objeto de tipo string que representa el nombre de la estrella.

    Returns:
        float: Valores mínimos y máximos de los ejes X y Y de la órbita.
    """
    star_planets = datos_orbita_sistema(datos, star_name)
    min_x, max_x, min_y, max_y = np.inf, -np.inf, np.inf, -np.inf
    
    for _, planet in star_planets.iterrows():
        x, y = calcular_orbita(
            semi_major_axis=float(planet['semi_major_axis']),
            eccentricity=float(planet['eccentricity']),
            omega=float(planet['omega']),
            tperi=float(planet['tperi']),
            T=float(planet['orbital_period']),
            num=1000
        )
        min_x = min(min_x, np.min(x))
        max_x = max(max_x, np.max(x))
        min_y = min(min_y, np.min(y))
        max_y = max(max_y, np.max(y))
    return min_x, max_x, min_y, max_y

def obtener_color_estrella(teff):
    """Función que obtiene el color de una estrella según su temperatura efectiva.
    """
    if pd.isna(teff):
        return 'magenta'
    elif teff > 28000:
        return 'slateblue'
    elif teff > 10000:
        return 'lightblue'
    elif teff > 7500:
        return 'white'
    elif teff > 6000:
        return 'palegoldenrod'
    elif teff > 5000:
        return 'yellow'
    elif teff > 3500:
        return 'orange'
    else:
        return 'red'

def obtener_clase_estrella(teff):
    """Función que obtiene la clase de una estrella según su temperatura efectiva.
    """
    if pd.isna(teff):
        return 'Desconocida'
    elif teff > 28000:
        return 'O'
    elif teff > 10000:
        return 'B'
    elif teff > 7500:
        return 'A'
    elif teff > 6000:
        return 'F'
    elif teff > 5000:
        return 'G'
    elif teff > 3500:
        return 'K'
    else:
        return 'M'

def calculo_velocidad(x, y, T):
    """Función que calcula la velocidad de un objeto en movimiento.
    """
    dx = np.diff(x)
    dy = np.diff(y)
    ds = np.sqrt(dx**2 + dy**2)
    dt = T / len(x)
    v = ds / dt
    v = np.append(v, v[-1])
    return v

def mostrar_datos_planetas(datos, star_name, root):
    """Función que muestra los datos de los planetas que orbitan alrededor de una estrella específica.
    """
    star_planets = datos_orbita_sistema(datos, star_name)
    
    if star_planets.empty:
        messagebox.showwarning("Advertencia", f"No se encontraron datos para la estrella {star_name}.")
        return
    
    datos_popup = Toplevel(root)
    datos_popup.title(f"Datos de los planetas para {star_name}")
    datos_popup.configure(bg="gray26")
    
    text_widget = tk.Text(datos_popup, wrap='word', bg="lightgrey", fg="black", font=("Helvetica", 12))
    text_widget.pack(expand=True, fill='both', padx=10, pady=10)
    
    for _, planet in star_planets.iterrows():
        text_widget.insert(tk.END, f"Planeta: {planet['name']}\n")
        text_widget.insert(tk.END, f"Semieje mayor: {planet['semi_major_axis']} AU\n")
        text_widget.insert(tk.END, f"Eccentricidad: {planet['eccentricity']}\n")
        text_widget.insert(tk.END, f"Omega: {planet['omega']} grados\n")
        text_widget.insert(tk.END, f"Tiempo en el periastro: {planet['tperi']} días\n")
        text_widget.insert(tk.END, f"Período orbital: {planet['orbital_period']} días\n")
        text_widget.insert(tk.END, f"masa del planeta:{planet['mass']}\n")
        text_widget.insert(tk.END, "-"*40 + "\n")
        
    text_widget.config(state=tk.DISABLED)

def animar_orbitas(datos, star_name, root, planet_marker_size=10):
    """Función que anima las órbitas de los planetas que orbitan alrededor de una estrella específica.
    """
    star_planets = datos_orbita_sistema(datos, star_name)
    
    if star_planets.empty:
        print(f"No se encontraron datos para la estrella {star_name}.")
        return
    
    popup = Toplevel(root)
    popup.title("Simulación Órbitas")
    popup.configure(bg="gray26")
    
    fig, ax = plt.subplots(figsize=(10, 10))
    
    min_x, max_x, min_y, max_y = obtener_limites_orbita(datos, star_name)
    
    if np.isinf([min_x, max_x, min_y, max_y]).any() or np.isnan([min_x, max_x, min_y, max_y]).any():
        message = f"Los límites de la órbita contienen valores NaN o Inf para la estrella {star_name}."
        messagebox.showwarning("Advertencia", message)
        return

    margin = 0.2
    min_x -= margin
    max_x += margin
    min_y -= margin
    max_y += margin
    
    star_x, star_y = calcular_posicion_estrella(datos, star_name)
    star_teff = star_planets.iloc[0]['star_teff']
    star_color = obtener_color_estrella(star_teff)
    star_class = obtener_clase_estrella(star_teff)
    
    ax.plot(star_x, star_y, 'o', label='Estrella Anfitriona', color=star_color, markersize=12, zorder=1)
    
    ax.text(0.05, 0.95, f'Temperatura: {star_teff} K\nClase Espectral: {star_class}', 
            transform=ax.transAxes, fontsize=10, verticalalignment='top', bbox=dict(facecolor='white', alpha=0.5))
    
    planet_lines = []
    planet_markers = []
    velocidad_texts = []
    tiempo_texts = []

    n_planets = len(star_planets)
    y_offset = 0.05

    for i, (_, planet) in enumerate(star_planets.iterrows()):
        if pd.notna(planet['semi_major_axis']) and pd.notna(planet['eccentricity']) and pd.notna(planet['omega']) and pd.notna(planet['tperi']) and pd.notna(planet['orbital_period']):
            x, y = calcular_orbita(
                semi_major_axis=planet['semi_major_axis'],
                eccentricity=planet['eccentricity'],
                omega=planet['omega'],
                tperi=planet['tperi'],
                T=planet['orbital_period'],
                num=1000
            )
            line, = ax.plot(x, y, label=planet['name'], zorder=1)
            planet_lines.append(line)
            marker, = ax.plot([], [], 'o', color=line.get_color(), markersize=planet_marker_size, zorder=1)
            planet_markers.append(marker)
            
            vel_text = ax.text(0.75, 0.30 - i * y_offset, '', transform=ax.transAxes, fontsize=10, verticalalignment='top',
                               bbox=dict(facecolor='white', alpha=0.5))
            velocidad_texts.append(vel_text)
            
            tiempo_text = ax.text(0.75, 0.30 - (i + n_planets) * y_offset, '', transform=ax.transAxes, fontsize=10, verticalalignment='top',
                                  bbox=dict(facecolor='white', alpha=0.5))
            tiempo_texts.append(tiempo_text)
        else:
            messagebox.showwarning("Advertencia", f"Datos insuficientes para graficar el sistema {planet['name']}.")
    
    boton_datos = Button(popup, text="Ver datos de los planetas", command=lambda: mostrar_datos_planetas(datos, star_name, root))
    boton_datos.pack(side=tk.LEFT, padx=10, pady=10)
    
    def init():
        ax.set_xlim(min_x, max_x)
        ax.set_ylim(min_y, max_y)
        ax.set_xlabel('Distancia (AU)')
        ax.set_ylabel('Distancia (AU)')
        ax.set_title(f'Órbitas de los exoplanetas alrededor de [{star_name}]')
        ax.legend()
        ax.grid(True)
        return planet_markers + velocidad_texts + tiempo_texts

    def update(frame):
        for i, (marker, vel_text, tiempo_text, (_, planet)) in enumerate(zip(planet_markers, velocidad_texts, tiempo_texts, star_planets.iterrows())):
            if pd.notna(planet['semi_major_axis']) and pd.notna(planet['eccentricity']) and pd.notna(planet['omega']) and pd.notna(planet['tperi']) and pd.notna(planet['orbital_period']):
                x, y = calcular_orbita(
                    semi_major_axis=planet['semi_major_axis'],
                    eccentricity=planet['eccentricity'],
                    omega=planet['omega'],
                    tperi=planet['tperi'],
                    T=planet['orbital_period'],
                    num=1000
                )

                v = calculo_velocidad(x, y, planet['orbital_period'])
                marker.set_data([x[frame % 1000]], [y[frame % 1000]])

                vel_text.set_text(f"{planet['name']} Velocidad: {v[frame % 1000]:.2f} AU/día")
                tiempo_transcurrido = (frame % 1000) * (planet['orbital_period'] / 1000)
                tiempo_text.set_text(f"{planet['name']} Tiempo: {tiempo_transcurrido:.2f} días")
        
        return planet_markers + velocidad_texts + tiempo_texts

    ani = FuncAnimation(fig, update, frames=1000, init_func=init, blit=True, interval=50, repeat=True)

    canvas = FigureCanvasTkAgg(fig, master=popup)
    canvas.draw()
    canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)

    botones_guardar_simulacion(popup, fig)
