import matplotlib.pyplot as plt
import numpy as np
import tkinter as tk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from Herramientas_Exoplanetarium.botones_guardar import crear_botones_guardar

def mapa_temperatura_estrellas(estrellas, ventana):
    """Función que grafica un mapa de temperatura de las estrellas.

    Args:
        estrellas (Class Estrella): Objeto de tipo Class Estrella que representa un conjunto de estrellas.
        ventana (Tkinter Object): Objeto de tipo Tkinter que representa la ventana donde se mostrará el gráfico
    """
    ras = [estrella.ra for estrella in estrellas]
    decs = [estrella.dec for estrella in estrellas]
    temperaturas = [estrella.temperatura for estrella in estrellas]

    #Convertimos las coordenadas de longitud (RA) de 0°-360° a -180° a 180°
    ras = np.where(np.array(ras) >= 180, np.array(ras) - 360, np.array(ras))

    fig = plt.figure(figsize=(10, 6))
    fig.subplots_adjust(left=0.07, bottom=0.07, right=0.98, top=0.97, hspace=0.02, wspace=0.08)

    ax1 = fig.add_subplot(111, projection="hammer")
    ax1.grid(True, lw=0.6, ls="-", color="gray")
    ax1.set_xlabel("Longitud galáctica (deg)", fontsize=9)
    ax1.set_ylabel("Latitud galáctica (deg)", fontsize=9)

    ax1.tick_params(axis='y', which='major', labelsize=8, colors="black")

    plt.setp(ax1.get_xticklabels(), visible=False)
    for lon in range(-150, 151, 30):
        ax1.text(np.deg2rad(lon), 0, f"${lon}^\circ$", fontsize=8, color="white", ha="center", va="bottom")

    #Convertimos las coordenadas a radianes para la proyección Hammer
    ras_rad = np.deg2rad(ras)
    decs_rad = np.deg2rad(decs)

    scatter = ax1.scatter(ras_rad, decs_rad, c=temperaturas, cmap='nipy_spectral_r', s=50, edgecolors='w')

    cbar = fig.colorbar(scatter, ax=ax1)
    cbar.set_label('Temperatura (K)')

    canvas = FigureCanvasTkAgg(fig, master=ventana)
    canvas.draw()
    canvas_widget = canvas.get_tk_widget()
    canvas_widget.pack(fill=tk.BOTH, expand=True)

    frame_botones = crear_botones_guardar(ventana, fig)
    frame_botones.pack(side=tk.BOTTOM, pady=10)

def mapa_temperatura_planetas(planetas, ventana):
    """Función que grafica un mapa de temperatura de los planetas.

    Args:
        planetas (Class Planeta): Objeto de tipo Class Planeta que representa un conjunto de planetas.
        ventana (Tkinter Object): Objeto de tipo Tkinter que representa la ventana donde se mostrará el gráfico
    """
    ras = [planeta.estrella_anfitriona.ra for planeta in planetas]
    decs = [planeta.estrella_anfitriona.dec for planeta in planetas]
    temperaturas = [planeta.temperatura for planeta in planetas]

    #Convertimos las coordenadas de longitud (RA) de 0°-360° a -180° a 180°
    ras = np.where(np.array(ras) >= 180, np.array(ras) - 360, np.array(ras))

    fig = plt.figure(figsize=(10, 6))
    fig.subplots_adjust(left=0.07, bottom=0.07, right=0.98, top=0.97, hspace=0.02, wspace=0.08)

    ax1 = fig.add_subplot(111, projection="hammer")
    ax1.grid(True, lw=0.6, ls="-", color="gray")
    ax1.set_xlabel("Longitud galáctica (deg)", fontsize=9)
    ax1.set_ylabel("Latitud galáctica (deg)", fontsize=9)

    ax1.tick_params(axis='y', which='major', labelsize=8, colors="black")

    plt.setp(ax1.get_xticklabels(), visible=False)
    ax1.text(np.deg2rad(-150), 0, r"$+150^\circ$", fontsize=8, color="white", ha="center", va="bottom")
    ax1.text(np.deg2rad(-120), 0, r"$+120^\circ$", fontsize=8, color="white", ha="center", va="bottom")
    ax1.text(np.deg2rad(-90), 0, r"$+90^\circ$", fontsize=8, color="white", ha="center", va="bottom")
    ax1.text(np.deg2rad(-60), 0, r"$+60^\circ$", fontsize=8, color="white", ha="center", va="bottom")
    ax1.text(np.deg2rad(-30), 0, r"$+30^\circ$", fontsize=8, color="white", ha="center", va="bottom")
    ax1.text(0, 0, r"$0^\circ$", fontsize=8, color="white", ha="center", va="bottom")
    ax1.text(np.deg2rad(150), 0, r"$-150^\circ$", fontsize=8, color="white", ha="center", va="bottom")
    ax1.text(np.deg2rad(120), 0, r"$-120^\circ$", fontsize=8, color="white", ha="center", va="bottom")
    ax1.text(np.deg2rad(90), 0, r"$-90^\circ$", fontsize=8, color="white", ha="center", va="bottom")
    ax1.text(np.deg2rad(60), 0, r"$-60^\circ$", fontsize=8, color="white", ha="center", va="bottom")
    ax1.text(np.deg2rad(30), 0, r"$-30^\circ$", fontsize=8, color="white", ha="center", va="bottom")

    #Convertimos las coordenadas a radianes para la proyección Hammer
    ras_rad = np.deg2rad(ras)
    decs_rad = np.deg2rad(decs)

    scatter = ax1.scatter(ras_rad, decs_rad, c=temperaturas, cmap='nipy_spectral_r', s=50, edgecolors='w')

    cbar = fig.colorbar(scatter, ax=ax1)
    cbar.set_label('Temperatura (K)')

    canvas = FigureCanvasTkAgg(fig, master=ventana)
    canvas.draw()
    canvas_widget = canvas.get_tk_widget()
    canvas_widget.pack(fill=tk.BOTH, expand=True)

    frame_botones = crear_botones_guardar(ventana, fig)
    frame_botones.pack(side=tk.BOTTOM, pady=10)
