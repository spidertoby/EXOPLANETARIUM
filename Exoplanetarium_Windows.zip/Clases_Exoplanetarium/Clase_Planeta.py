import numpy as np

class Planeta:
    """Clase que define un exoplaneta y sus propiedades.
    """
    def __init__(self, nombre, masa, radio, semi_major_axis, inclinacion, excentricidad, argumento_periastron, temperatura, estrella_anfitriona):
        """Función que inicializa un objeto de la clase Planeta.

        Args:
            nombre (string): Objeto de tipo string que representa el nombre del planeta.
            masa (float): Objeto de tipo float que representa la masa del planeta en masas de Júpiter.
            radio (float): Objeto de tipo float que representa el radio del planeta en radios de Júpiter.
            semi_major_axis (float): Objeto de tipo float que representa el semieje mayor de la órbita del planeta en UA.
            inclinacion (float): Objeto de tipo float que representa la inclinación de la órbita del planeta en grados.
            excentricidad (float): Objeto de tipo float que representa la excentricidad de la órbita del planeta.
            argumento_periastron (float): Objeto de tipo float que representa el argumento del periastron de la órbita del planeta en grados.
            temperatura (float): Objeto de tipo float que representa la temperatura de equilibrio del planeta en Kelvin.
            estrella_anfitriona (string): Objeto de tipo string que representa el nombre de la estrella anfitriona del planeta.
        """
        self.nombre = nombre
        self.masa = masa
        self.radio = radio
        self.semi_major_axis = semi_major_axis
        self.inclinacion = inclinacion
        self.excentricidad = excentricidad
        self.argumento_periastron = argumento_periastron
        self.temperatura = temperatura
        self.estrella_anfitriona = estrella_anfitriona
        
    def clasificacion_planetaria(self):
        """Función que clasifica al planeta en base a su temperatura de equilibrio.

        Returns:
            string: Objeto de tipo string que representa la clase del planeta.
        """
        if self.temperatura >= 2000:
            return "Clase Alta"
        elif self.temperatura >= 1000:
            return "Clase Media"
        else:
            return "Clase Baja"
