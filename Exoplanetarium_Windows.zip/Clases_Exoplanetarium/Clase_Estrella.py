class Estrella:
    def __init__(self, nombre, masa, radio, temperatura, distancia, ra, dec):
        """Función que inicializa un objeto de la clase Estrella.

        Args:
            nombre (string): Objeto de tipo string que representa el nombre de la estrella.
            masa (float): Objeto de tipo float que representa la masa de la estrella en masas solares.
            radio (float): Objeto de tipo float que representa el radio de la estrella en radios solares.
            temperatura (float): Objeto de tipo float que representa la temperatura efectiva de la estrella en Kelvin.
            distancia (float): Objeto de tipo float que representa la distancia de la estrella a la Tierra en parsecs.
            ra (float): Objeto de tipo float que representa la ascensión recta de la estrella en grados.
            dec (float): Objeto de tipo float que representa la declinación de la estrella en grados.
        """
        self.nombre = nombre
        self.masa = masa
        self.radio = radio
        self.temperatura = temperatura
        self.distancia = distancia
        self.ra = ra
        self.dec = dec

    def luminosidad_secuencia(self):
        """
        Calcula la luminosidad de la secuencia principal de la estrella en unidades de luminosidad solar.
        """
        return self.masa**3.5

    def clasificacion_espectral(self):
        """Función que clasifica a la estrella en base a su temperatura efectiva.

        Returns:
            string: Objeto de tipo string que representa la clase espectral de la estrella.
        """
        if self.temperatura is None:
            return 'Clase Desconocida'
        elif self.temperatura >= 30000:
            return 'Clase O'
        elif self.temperatura >= 10000:
            return 'Clase B'
        elif self.temperatura >= 7500:
            return 'Clase A'
        elif self.temperatura >= 6000:
            return 'Clase F'
        elif self.temperatura >= 5200:
            return 'Clase G'
        elif self.temperatura >= 3700:
            return 'Clase K'
        else:
            return 'Clase M'
        

