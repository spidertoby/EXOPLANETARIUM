import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter as tk
from tkinter import Button, Label, messagebox, filedialog, ttk, Toplevel, Checkbutton, IntVar
from Herramientas_Exoplanetarium.botones_guardar import crear_botones_guardar

def graficar_diagrama_hr(estrellas, ventana):
    """Función que grafica un diagrama de Hertzsprung-Russell para un conjunto de estrellas.

    Args:
        estrellas (Class Estrella): Objeto de tipo Class Estrella que representa un conjunto de estrellas.
        ventana (Tkinter Object): Objeto de tipo Tkinter que representa la ventana donde se mostrará el gráfico
    """
    temperaturas = [estrella.temperatura for estrella in estrellas]
    luminosidades = [estrella.luminosidad_secuencia() for estrella in estrellas]
    clasificaciones = [estrella.clasificacion_espectral() for estrella in estrellas]

    colores = {
        'Clase O': 'slateblue',
        'Clase B': 'lightblue',
        'Clase A': 'white',
        'Clase F': 'palegoldenrod',
        'Clase G': 'yellow',
        'Clase K': 'orange',
        'Clase M': 'red',
        'Clase Desconocida': 'magenta'
    }

    fig, ax = plt.subplots(figsize=(6, 7), facecolor='black')
    fig.patch.set_facecolor('black')
    ax.set_facecolor('black')
    ax.tick_params(colors='white')

    for clase_espectral in colores.keys():
        """Función que grafica un conjunto de estrellas en un diagrama de Hertzsprung-Russell.

        Args:
            ax (variable): Objeto de tipo variable que representa los ejes del gráfico.
        """
        indices = [i for i, c in enumerate(clasificaciones) if c == clase_espectral or (clase_espectral == 'Clase Desconocida' and c is None)]
        ax.scatter(
            [temperaturas[i] if temperaturas[i] is not None else 0 for i in indices],
            [luminosidades[i] for i in indices],
            color=colores[clase_espectral],
            label=clase_espectral,
            s=100,
            marker='*',
            edgecolor='black',
            linewidth=0.5,
            alpha=0.8
        )

    ax.invert_xaxis()
    ax.set_yscale('log')
    ax.set_xlabel('Temperatura (K)', color='white', font="Times New Roman", size=15)
    ax.set_ylabel('Luminosidad (Luminosidad Solar)', color='white', font="Times New Roman", size=15)
    ax.legend(title='Clasificación Espectral', loc='lower left', fontsize=10, facecolor='white', edgecolor='white')
    ax.tick_params(axis='x', colors='white')
    ax.tick_params(axis='y', colors='white')

    num_estrellas = len(estrellas)
    ax.set_title(f'Diagrama de Hertzsprung-Russell para Estrellas (Número de estrellas: {num_estrellas})', color='white', font="Times New Roman", size=16)

    ax.spines['bottom'].set_color('white')
    ax.spines['top'].set_color('white')
    ax.spines['right'].set_color('white')
    ax.spines['left'].set_color('white')

    ax.xaxis.label.set_color('white')
    ax.yaxis.label.set_color('white')

    ax.tick_params(axis='x', colors='white')
    ax.tick_params(axis='y', colors='white')

    plt.tight_layout()
    plt.grid(True, which='both', linestyle='--', linewidth=0.5, color='gray')

    canvas = FigureCanvasTkAgg(fig, master=ventana)
    canvas.draw()
    canvas_widget = canvas.get_tk_widget()
    canvas_widget.pack(fill=tk.BOTH, expand=True)

    frame_botones = crear_botones_guardar(ventana, fig)
    frame_botones.pack(side=tk.BOTTOM, pady=10)

    ventana.update()

    canvas_width, canvas_height = fig.get_size_inches() * fig.get_dpi()
    boton_height = frame_botones.winfo_height()
    ventana.geometry(f"{int(canvas_width)}x{int(canvas_height + boton_height + 40)}")
