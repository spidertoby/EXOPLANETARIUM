import os
import sys
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import io
import time
import tkinter as tk
from tkinter import Button, Label, messagebox, filedialog, ttk, Toplevel, Checkbutton, IntVar
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.animation import FuncAnimation



# Obtiene la ruta del directorio actual
try:
    # Intenta obtener la ruta usando __file__ (funciona en scripts)
    current_dir = os.path.dirname(os.path.abspath(__file__))
except NameError:
    # Si __file__ no está definido (en notebooks), usa el directorio de trabajo actual
    current_dir = os.getcwd()

# Obtiene la ruta del directorio padre
parent_dir = os.path.dirname(current_dir)

# Añade la ruta del directorio padre a sys.path
sys.path.append(parent_dir)


# In[3]:



from Clases_Exoplanetarium.Clase_Estrella import Estrella
from Clases_Exoplanetarium.Clase_Planeta import Planeta
from Clases_Exoplanetarium.diagrama_hr import graficar_diagrama_hr
from Clases_Exoplanetarium.scatter_plot import plot_scatter
from Clases_Exoplanetarium.histograma import plot_histograma_grafico
from Clases_Exoplanetarium.simulacion_orbitas import datos_orbita_sistema, calcular_orbita, calcular_baricentro, calcular_posicion_estrella, obtener_limites_orbita, obtener_color_estrella, obtener_clase_estrella, animar_orbitas
from Clases_Exoplanetarium.mapas_temperatura import mapa_temperatura_estrellas, mapa_temperatura_planetas


# Inicializar variable global para los datos
datos = None
### PARTE 1: DATOS
 
# Función para descargar datos
def descargar_datos(url, download_dir):
    chrome_options = Options()
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": download_dir,
        "download.prompt_for_download": False,
        "safebrowsing.enabled": True,
        "profile.default_content_settings.popups": 0,
        "plugins.always_open_pdf_externally": True
    })
    chrome_options.add_argument("--headless")  # Hace "invisible" la ventana emergente que se genera al empezar la descarga
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--window-size=1920x1080")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Descargar y configurar ChromeDriver automáticamente
    
    
    script_dir = os.path.dirname(os.path.abspath(__file__))
    # Ruta relativa al chromedriver
    chromedriver_path = os.path.join(script_dir, "chrome_driver", "chromedriver.exe")
    service = Service(chromedriver_path)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    
    archivo_descargado = os.path.join(download_dir, "download.csv")  # nombre del archivo descargado
    if os.path.exists(archivo_descargado):
        os.remove(archivo_descargado)  # Eliminar archivo existente con el mismo nombre

    try:
        driver.get(url)
        wait = WebDriverWait(driver, 20)
        boton_descarga = wait.until(EC.element_to_be_clickable((By.XPATH, '//*[@id="downloads-section"]/div/div/div[1]/a')))
        boton_descarga.click()
        time.sleep(90)  # Podrías aumentar este tiempo
        print(f"Intentando descargar en: {download_dir}")
        print(f"Archivo descargado esperado en: {archivo_descargado}")
    except Exception as e:
        print(f"Error durante la descarga: {e}")
    finally:
        driver.quit()

    if os.path.exists(archivo_descargado):
        try:
            with open(archivo_descargado, 'r', encoding='utf-8') as file:
                datos_csv = file.read()
        except FileNotFoundError:
            messagebox.showerror("Error", "El archivo descargado no se encontró.")
            datos_csv = None
    else:
        messagebox.showerror("Error", "El archivo no se descargó correctamente.")
        datos_csv = None

    return datos_csv

# Función para cargar los datos
def cargar_datos():
    global datos, estrellas, planetas
    url = "https://exoplanet.eu/catalog/#"
    current_dir = os.getcwd()
    download_dir = os.path.join(current_dir, "Testeo_Descarga")
    os.makedirs(download_dir, exist_ok=True)
    
    datos_csv = descargar_datos(url, download_dir)

    if datos_csv:
        try:
            datos = pd.read_csv(io.StringIO(datos_csv))
            label_status.config(text="¡Datos cargados exitosamente!", fg="green")
            combobox_x['values'] = list(param_map_es_to_en.keys())
            combobox_y['values'] = list(param_map_es_to_en.keys())
            print("Columnas cargadas:", datos.columns)
            # Crear una lista de objetos Estrella y Planeta
            estrellas = []
            for index, row in datos.iterrows():
                estrella = Estrella(
                    nombre=row['star_name'],
                    masa=row['star_mass'],
                    radio=row['star_radius'],
                    temperatura=row['star_teff'],
                    distancia=row['star_distance'],
                    ra=row['ra'],
                    dec=row['dec']
                )
                estrellas.append(estrella)
            # Crear una lista de objetos Planeta
            planetas = []
            for index, row in datos.iterrows():
                estrella_anfitriona = next((e for e in estrellas if e.nombre == row['star_name']), None)
                if estrella_anfitriona:
                    planeta = Planeta(
                        nombre=row['name'],
                        masa=row['mass'],
                        radio=row['radius'],
                        semi_major_axis=row['semi_major_axis'],
                        inclinacion=row['inclination'],
                        excentricidad=row['eccentricity'],
                        argumento_periastron=row['omega'],
                        temperatura=row['temp_calculated'],
                        estrella_anfitriona=estrella_anfitriona
                    )
                    planetas.append(planeta)


        except KeyError as e:
            label_status.config(text="No se pudieron cargar los datos :(", fg="red")
            messagebox.showerror("Error", f"Columna no encontrada en el archivo CSV: {e}")
        except Exception as e:
            label_status.config(text="No se pudieron cargar los datos :(", fg="red")
            messagebox.showerror("Error", f"Error al cargar y procesar datos: {e}")




 ## Creación y manejo de ventanas

# In[7]:


def mostrar_pantalla_principal():
    frame_principal.pack(fill='both', expand=True)
    frame_secundario.pack_forget()
    frame_scatter.pack_forget()
    frame_diagrama.pack_forget()
    frame_hist.pack_forget()
    frame_orb.pack_forget()
    frame_mapa.pack_forget()


# In[8]:


def mostrar_pantalla_secundaria():
    frame_principal.pack_forget()
    frame_secundario.pack(fill='both', expand=True)
    frame_scatter.pack_forget()
    frame_diagrama.pack_forget()
    frame_hist.pack_forget()
    frame_orb.pack_forget()
    frame_mapa.pack_forget()


# In[9]:


def mostrar_pantalla_scatter():
    frame_principal.pack_forget()
    frame_secundario.pack_forget()
    frame_orb.pack_forget()
    frame_hist.pack_forget()
    frame_diagrama.pack_forget()
    frame_mapa.pack_forget()
    frame_scatter.pack(fill='both', expand=True)


# In[10]:


def mostrar_pantalla_diagrama():
    frame_principal.pack_forget()
    frame_secundario.pack_forget()
    frame_scatter.pack_forget()
    frame_orb.pack_forget()
    frame_hist.pack_forget()
    frame_mapa.pack_forget()
    frame_diagrama.pack(fill='both', expand=True)


# In[11]:


def mostrar_pantalla_histograma():
    frame_principal.pack_forget()
    frame_secundario.pack_forget()
    frame_scatter.pack_forget()
    frame_orb.pack_forget()
    frame_diagrama.pack_forget()
    frame_mapa.pack_forget()
    frame_hist.pack(fill='both', expand=True)


# In[12]:


def mostrar_pantalla_orbita():
    frame_principal.pack_forget()
    frame_secundario.pack_forget()
    frame_scatter.pack_forget()
    frame_diagrama.pack_forget()
    frame_hist.pack_forget()
    frame_mapa.pack_forget()
    frame_orb.pack(fill='both', expand=True)


def mostrar_pantalla_mapa():
    frame_principal.pack_forget()
    frame_secundario.pack_forget()
    frame_scatter.pack_forget()
    frame_diagrama.pack_forget()
    frame_hist.pack_forget()
    frame_orb.pack_forget()
    frame_mapa.pack(fill='both', expand=True)



# ## Manejo de gráficos y animaciones

# ### Diagrama H-R

# In[13]:


def plot_diagrama_hr():
    global estrellas
    if estrellas is None:
        messagebox.showerror("Error", "Primero debe cargar los datos.")
        return

    try:
        # Crear una nueva ventana para el gráfico
        popup = Toplevel(root)
        popup.title("Diagrama HR")
        popup.configure(bg="gray26")

        # Crear el gráfico
        graficar_diagrama_hr(estrellas, popup)

    except KeyError as e:
        messagebox.showerror("Error", f"Columna no encontrada: {e}")


# ### Scatter Plot

# In[14]:


def on_plot_scatter():
    global datos
    if datos is None:
        messagebox.showerror("Error", "Primero debe cargar los datos.")
        return
    x_param_es = combobox_x.get()
    y_param_es = combobox_y.get()
    mostrar_temperatura = var_mostrar_temperatura.get() == 1
    plot_scatter(root, datos, x_param_es, y_param_es, param_map_es_to_en, mostrar_temperatura)


# ### Histogramas

# In[15]:


def plot_histograma():
    global datos
    if datos is None:
        messagebox.showerror("Error", "Primero debe cargar los datos.")
        return
    
    x_param_es = combobox_x_hist.get()
    tipo_param = combobox_tipo_hist.get().lower()
    
    try:
        plot_histograma_grafico(root, datos, x_param_es, tipo_param, param_map_es_to_en)
    except (KeyError, ValueError) as e:
        messagebox.showerror("Error", str(e))

# Asegúrate de que el botón para generar el histograma llame a on_plot_histograma


# In[16]:


# Función para actualizar las opciones de combobox según el tipo de histograma seleccionado
def actualizar_opciones_histograma(event):
    tipo_param = combobox_tipo_hist.get().lower()
    if tipo_param == "estrellas":
        combobox_x_hist['values'] = [key for key, value in param_map_es_to_en.items() if value in opciones_estrellas]
    elif tipo_param == "exoplanetas":
        combobox_x_hist['values'] = [key for key, value in param_map_es_to_en.items() if value in opciones_planetas]
    else:
        messagebox.showerror("Error", "Tipo de histograma no válido")


# ### Simulación de Órbitas

# In[17]:


# Definir opciones de estrellas y exoplanetas
opciones_estrellas = ["star_mass", "star_radius", "star_distance", "star_metallicity", "star_age",
                      "star_teff", "ra", "dec", "mag_v", "mag_i", "mag_j", "mag_h", "mag_k"]

opciones_planetas = ["mass", "mass_sini", "radius", "orbital_period", "semi_major_axis", "eccentricity", 
                     "inclination", "angular_distance", "discovered", "omega", "tperi", "tconj", "tzero_tr", 
                     "tzero_tr_sec", "lambda_angle", "impact_parameter", "tzero_vr", "k", "temp_calculated", 
                     "temp_measured", "hot_point_lon", "geometric_albedo", "log_g", "detection_type"]
## Simulacion de Orbitas
# Dataframe con los nombres de las estrellas anfitrionas
orbital_data = pd.DataFrame(datos, columns=["star_name", "star_mass", "name", "mass", "orbital_period", "semi_major_axis", "eccentricity", "omega", "tperi", "star_teff"])
orbital_data_clean = orbital_data.dropna(subset=["star_name", "star_mass", "name", "mass", "orbital_period", "semi_major_axis", "eccentricity", "omega", "tperi"]) # Eliminar valores nulos relevantes
star_names = pd.DataFrame(orbital_data_clean, columns=["star_name"])



def mostrar_sistemas_planetarios():
    global combo_box
    if combo_box.winfo_viewable():
        combo_box.place_forget()
    else:
        combo_box['values'] = star_names['star_name'].unique().tolist()
        combo_box.place(x=110, y=300)

def graficar_orbitas():
    star_name = combo_box.get()
    fig, ani = animar_orbitas(star_name)
    
    if fig is not None:
        popup = Toplevel(root)
        popup.title("Simulación Órbitas")
        popup.configure(bg="gray26")
        
        canvas = FigureCanvasTkAgg(fig, master=popup)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

def datos_orbita_sistema(star_name):
    star_planets = datos[datos['star_name'] == star_name]
    return star_planets

# Función para mostrar los sistemas planetarios
def mostrar_sistemas_planetarios():
    global combo_box
    if combo_box.winfo_viewable():
        combo_box.place_forget()
    else:
        combo_box['values'] = datos['star_name'].unique().tolist()
        combo_box.place(x=110, y=300)


def graficar_orbitas():
    star_name = combo_box.get()
    animar_orbitas(datos, star_name, root)


# ### Mapas de Temperatura
def plot_mapa_estrella():
    global estrellas
    if estrellas is None:
        messagebox.showerror("Error", "Primero debe cargar los datos.")
        return

    try:
        # Crear una nueva ventana para el gráfico
        popup = Toplevel(root)
        popup.title("Mapa de Temperatura Superficial de Estrellas Anfitrionas")
        popup.configure(bg="gray26")

        # Crear el gráfico
        mapa_temperatura_estrellas(estrellas, popup)

    except KeyError as e:
        messagebox.showerror("Error", f"Columna no encontrada: {e}")


# ### Mapas de Temperatura
def plot_mapa_estrella():
    global estrellas
    if not estrellas:
        messagebox.showerror("Error", "Primero debe cargar los datos.")
        return

    try:
        # Crear una nueva ventana para el gráfico
        popup = Toplevel(root)
        popup.title("Mapa de Temperatura Superficial de Estrellas Anfitrionas")
        popup.configure(bg="gray26")

        # Crear el gráfico
        mapa_temperatura_estrellas(estrellas, popup)

    except KeyError as e:
        messagebox.showerror("Error", f"Columna no encontrada: {e}")

def plot_mapa_planeta():
    global planetas
    if not planetas:
        messagebox.showerror("Error", "Primero debe cargar los datos.")
        return

    try:
        # Crear una nueva ventana para el gráfico
        popup = Toplevel(root)
        popup.title("Mapa de Temperatura Superficial de Exoplanetas")
        popup.configure(bg="gray26")

        # Crear el gráfico
        mapa_temperatura_planetas(planetas, popup)

    except KeyError as e:
        messagebox.showerror("Error", f"Columna no encontrada: {e}")




# ## Manejo de la interfáz Gráfica
# ### Frame principal

# In[18]:


root = tk.Tk()
root.title("EXOPLANETARIUM")
root.geometry("1080x720")
root.configure(bg="gray26")


# In[19]:


frame_principal = tk.Frame(root, bg="gray26")
frame_principal.pack(fill='both', expand=True)


# In[20]:


# Crear un frame para el título
frame_titulo = tk.Frame(frame_principal, bg="gray26")
frame_titulo.pack(fill=tk.X)


# In[21]:


# Crear el título y agregarlo al frame del título
titulo = tk.Label(frame_titulo, text="EXOPLANETARIUM", background="gray26", font=("Times New Roman", 40), fg="white")
titulo.pack(pady=10)


# In[22]:


# Contenedor para centrar elementos
frame_central = tk.Frame(frame_principal, bg="gray26")
frame_central.pack(expand=True)


# In[23]:


# Etiqueta de estado inicial
label_instruccion = Label(frame_central, text="¡Carga los datos antes de comenzar a graficar!", font=("Times New Roman", 14), bg="gray26")
label_instruccion.pack(pady=20)


# In[24]:


# Botón "Cargar Datos"
button_cargar = Button(frame_central, text="Cargar Datos", command=cargar_datos, width=15, height=2, font=("Times New Roman", 12, "bold"), bg="#b19cd9")
button_cargar.pack(pady=10)


# In[25]:


# Etiqueta de estado debajo del botón "Cargar Datos"
label_status = Label(frame_central, text="", font=("Times New Roman", 14), bg="gray26")
label_status.pack(pady=20)


# In[26]:


# Botón "Start" abajo del todo
button_start = Button(frame_principal, text="Start", width=10, height=2, font=("Times New Roman", 12, "bold"), bg="#74D153", command=mostrar_pantalla_secundaria)
button_start.pack(side=tk.BOTTOM, pady=20)


# In[27]:


# Frame secundario (Menú de opciones de gráficos)
frame_secundario = tk.Frame(root, bg="gray26")


# In[28]:


# Botón de retroceso
button_back_secundario = Button(frame_secundario, text="<", command=mostrar_pantalla_principal, width=2, height=2, font=("Times New Roman", 12, "bold"), bg="gray26", fg="white")
button_back_secundario.grid(row=0, column=0, sticky='w', pady=20)


# In[29]:


# Botones para las opciones de gráficos en columnas
button_scatter = Button(frame_secundario, text="Scatter Plot", command=mostrar_pantalla_scatter, width=22, height=2, font=("Times New Roman", 12, "bold"), bg="#b19cd9")
button_scatter.grid(row=1, column=0, padx=10, pady=10)


# In[30]:


button_hr = Button(frame_secundario, text="Diagrama HR", command=mostrar_pantalla_diagrama, width=22, height=2, font=("Times New Roman", 12, "bold"), bg="#b19cd9")
button_hr.grid(row=1, column=1, padx=10, pady=10)


# In[31]:


button_histogram = Button(frame_secundario, text="Histogramas", command=mostrar_pantalla_histograma, width=22, height=2, font=("Times New Roman", 12, "bold"), bg="#b19cd9")
button_histogram.grid(row=1, column=2, padx=10, pady=10)


# In[32]:


button_simulations = Button(frame_secundario, text="Simulaciones de Órbitas", command= mostrar_pantalla_orbita, width=22, height=2, font=("Times New Roman", 12, "bold"), bg="#b19cd9")
button_simulations.grid(row=1, column=3, padx=10, pady=10)



button_maps = Button(frame_secundario, text="Mapas de Temperatura", command= mostrar_pantalla_mapa, width=22, height=2, font=("Times New Roman", 12, "bold"), bg="#b19cd9")
button_maps.grid(row=1, column=4, padx=10, pady=10)


# ### Manejo de pantallas secundarias

# In[33]:


### PARTE 5: PANTALLAS SECUNDARIAS (FRAMES)
## Frame para Diagrama H-R
frame_diagrama = tk.Frame(root, bg="gray26")


# In[34]:


# Botón de retroceso
button_back_diagrama = Button(frame_diagrama, text="<", command=mostrar_pantalla_secundaria, width=2, height=2, font=("Times New Roman", 12, "bold"), bg="gray26", fg="white")
button_back_diagrama.pack(anchor='nw', padx=10, pady=10)


# In[35]:


# Etiqueta de Diagrama H-R
label_diagrama = Label(frame_diagrama, text="Graficar Diagrama H-R", font=("Times New Roman", 14), bg="gray26")
label_diagrama.pack(pady=20)


# In[36]:


# Botón para graficar
plot_button = Button(frame_diagrama, text="Graficar", command=plot_diagrama_hr, width=15, height=2, font=("Times New Roman", 12, "bold"), bg="#74D153")
plot_button.pack(pady=20)


# In[37]:


## Frame para Scatter Plot
frame_scatter = tk.Frame(root, bg="gray26")


# In[38]:


# Botón de retroceso
button_back_scatter = Button(frame_scatter, text="<", command=mostrar_pantalla_secundaria, width=2, height=2, font=("Times New Roman", 12, "bold"), bg="gray26", fg="white")
button_back_scatter.pack(anchor='nw', padx=10, pady=10)


# In[39]:


# Etiqueta de Scatter Plot
label_scatter = Label(frame_scatter, text="Opciones de Scatter Plot", font=("Times New Roman", 14), bg="gray26")
label_scatter.pack(pady=20)


# In[40]:


# Mapa de nombres en español a nombres en inglés
param_map_es_to_en = {
    "Distancia angular": "angular_distance",
    "Argumento del periastrón": "omega",
    "Temperatura calculada": "temp_calculated",
    "Fecha de conjunción": "tconj",
    "Época del Periastrón": "tperi",
    "Albedo geométrico": "geometric_albedo",
    "Longitud del punto más caliente": "hot_point_lon",
    "Parámetro de impacto b": "impact_parameter",
    "Temperatura medida": "temp_measured",
    "Excentricidad orbital": "eccentricity",
    "Inclinación orbital": "inclination",
    "Período orbital": "orbital_period",
    "Masa planetaria": "mass",
    "Masa planetaria*sin(i)": "mass_sini",
    "Radio planetario": "radius",
    "Tránsito primario": "tzero_tr",
    "Tránsito secundario": "tzero_tr_sec",
    "Semieje mayor": "semi_major_axis",
    "Ángulo proyectado en el cielo entre el giro orbital planetario y el giro estelar": "lambda_angle",
    "Velocidad Semiamplitud K": "k",
    "Año de descubrimiento": "discovered",
    "Cero Tiempo de velocidad radial": "tzero_vr",
    "Log(g)": "log_g",
    "Edad de la estrella anfitriona": "star_age",
    "Dec (J2000) de una estrella": "dec",
    "Distancia a la estrella anfitriona": "star_distance",
    "Temperatura efectiva de la estrella anfitriona": "star_teff",
    "Magnitud H de la estrella anfitriona": "mag_h",
    "Magnitud I de la estrella anfitriona": "mag_i",
    "Magnitud J de la estrella anfitriona": "mag_j",
    "Metalidad de la estrella anfitriona": "star_metallicity",
    "Magnitud R de la estrella anfitriona": "mag_r",
    "Ascensión recta (J2000) de una estrella": "ra",
    "Radio de la estrella anfitriona": "star_radius",
    "Magnitud V de la estrella anfitriona": "mag_v",
    "Masa de la estrella anfitriona": "star_mass",
}


# In[41]:


# Combobox para el eje X
label_x = ttk.Label(frame_scatter, text="Seleccione el parámetro para el eje X:")
label_x.pack(pady=10)
combobox_x = ttk.Combobox(frame_scatter, values=list(param_map_es_to_en.keys()))
combobox_x.pack(pady=10)


# In[42]:


# Combobox para el eje Y
label_y = ttk.Label(frame_scatter, text="Seleccione el parámetro para el eje Y:")
label_y.pack(pady=10)
combobox_y = ttk.Combobox(frame_scatter, values=list(param_map_es_to_en.keys()))
combobox_y.pack(pady=10)


# In[43]:


# Opción para mostrar temperatura superficial con barra de color
var_mostrar_temperatura = IntVar()
check_mostrar_temperatura = Checkbutton(frame_scatter, text="Mostrar Temperatura Superficial", variable=var_mostrar_temperatura, font=("Times New Roman", 12), bg="gray26", fg="white")
check_mostrar_temperatura.pack(pady=10)


# In[44]:


# Botón para graficar
plot_button = Button(frame_scatter, text="Graficar", command=on_plot_scatter, width=15, height=2, font=("Times New Roman", 12, "bold"), bg="#74D153")
plot_button.pack(pady=20)


# In[45]:


## Frame para Histogramas
frame_hist = tk.Frame(root, bg="gray26")


# In[46]:


# Botón de retroceso Histograma
button_back_hist = Button(frame_hist, text="<", command=mostrar_pantalla_secundaria, width=2, height=2, font=("Times New Roman", 12, "bold"), bg="gray26", fg="white")
button_back_hist.pack(anchor='nw', padx=10, pady=10)


# In[47]:


# Etiqueta de Histograma
label_hist = Label(frame_hist, text="Opciones de Histograma", font=("Times New Roman", 14), bg="gray26")
label_hist.pack(pady=20)


# In[48]:


# Combobox para el tipo de histograma
tipo_hist = ["Estrellas", "Exoplanetas"]
label_tipo_hist = ttk.Label(frame_hist, text="Seleccione el tipo de histograma:")
label_tipo_hist.pack(pady=10)
combobox_tipo_hist = ttk.Combobox(frame_hist, values=tipo_hist)
# Asociar la función de actualización al evento de cambio en combobox_tipo_hist
combobox_tipo_hist.bind("<<ComboboxSelected>>", actualizar_opciones_histograma)
combobox_tipo_hist.pack(pady=10)
# Combobox para el eje X
label_x_hist = ttk.Label(frame_hist, text="Seleccione el parámetro para el eje X:")
label_x_hist.pack(pady=10)
combobox_x_hist = ttk.Combobox(frame_hist, values=list(param_map_es_to_en.keys()))
combobox_x_hist.pack(pady=10)


# In[49]:


# Boton para graficar Histograma
plot_button_hist = Button(frame_hist, text="Graficar", command=plot_histograma, width=15, height=2, font=("Times New Roman", 12, "bold"), bg="#74D153")
plot_button_hist.pack(pady=20)


# In[50]:


## Frame para Orbitas
frame_orb = tk.Frame(root, bg="gray26")


# In[51]:


Sub_titulo = tk.Label(frame_orb, text="Simulacion de orbitas", background="gray26", font=("Times", 15))
Sub_titulo.place(x=500, y=100)


# In[52]:


button_back_orbit = Button(frame_orb, text="<", command=mostrar_pantalla_secundaria, width=2, height=2, font=("Times New Roman", 12, "bold"), bg="gray26", fg="white")
button_back_orbit.pack(anchor='nw', padx=10, pady=10)


# In[53]:


Pregunta_usuario = tk.Label(frame_orb, text="¿Que sistema quieres graficar?", background="gray26", font=("Times",15))
Pregunta_usuario.place(x=20, y=180)


# In[54]:


combo_box = ttk.Combobox(frame_orb, font=("Times", 20))


# In[55]:


Boton_planetario = tk.Button(frame_orb, text="Sistemas Planetarios",command=mostrar_sistemas_planetarios, font=("Times", 14))
Boton_planetario.place(x=110, y=250)


# In[56]:


Graficar_sistema = tk.Button(frame_orb, text="Graficar",command= graficar_orbitas, font=("Times", 12))
Graficar_sistema.place(x=175, y=500)


# In[57]:

#Frame para Mapas de Temperatura

frame_mapa = tk.Frame(root, bg="gray26")

#Botón de retroceso
button_back_mapa = Button(frame_mapa, text="<", command=mostrar_pantalla_secundaria, width=2, height=2, font=("Times New Roman", 12, "bold"), bg="gray26", fg="white")
button_back_mapa.pack(anchor='nw', padx=10, pady=10)

#Etiqueta de Mapa de Temperatura
label_mapa = Label(frame_mapa, text="Mapas de Temperatura", font=("Times New Roman", 14), bg="gray26")
label_mapa.pack(pady=20)

#Botón para graficar
plot_button_mapa_estrella = Button(frame_mapa, text="Graficar Mapa de Estrellas", command=plot_mapa_estrella, width=25, height=2, font=("Times New Roman", 12, "bold"), bg="#74D153")
plot_button_mapa_estrella.pack(pady=20)

plot_button_mapa_planeta = Button(frame_mapa, text="Graficar Mapa de Exoplanetas", command=plot_mapa_planeta, width=25, height=2, font=("Times New Roman", 12, "bold"), bg="#74D153")
plot_button_mapa_planeta.pack(pady=20)

root.mainloop()
