#!/usr/bin/env python
# coding: utf-8

# In[1]:


import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter as tk
from tkinter import messagebox, Toplevel

def plot_scatter(root, datos, x_param_es, y_param_es, param_map_es_to_en, mostrar_temperatura):
    # Convertir nombres en español a nombres en inglés
    x_param = param_map_es_to_en.get(x_param_es)
    y_param = param_map_es_to_en.get(y_param_es)
    
    if x_param and y_param:
        try:
            print(f"Parámetro X seleccionado: {x_param}")
            print(f"Parámetro Y seleccionado: {y_param}")
            
            # Crear una nueva ventana para el gráfico
            popup = Toplevel(root)
            popup.title("Scatter Plot")
            popup.configure(bg="gray26")
            
            # Contar el número de planetas graficados
            num_planetas = len(datos[x_param])
            
            # Crear el gráfico
            fig, ax = plt.subplots()
            
            # Scatter plot estándar o con temperatura superficial
            if mostrar_temperatura:
                scatter = ax.scatter(datos[x_param], datos[y_param], c=datos['temp_calculated'], cmap='nipy_spectral_r', alpha=0.7)
                cbar = plt.colorbar(scatter)
                cbar.set_label('Temperatura Superficial (K)')
            else:
                scatter = ax.scatter(datos[x_param], datos[y_param])
            
            ax.set_xlabel(x_param_es)
            ax.set_ylabel(y_param_es)
            ax.set_title(f"Scatter Plot de {x_param_es} vs {y_param_es}")
            
            # Agregar el número de planetas graficados
            ax.text(0.98, 0.98, f"Total planetas: {num_planetas}", transform=ax.transAxes, horizontalalignment='right', verticalalignment='top', fontsize=10, bbox=dict(facecolor='white', alpha=0.5))
            
            # Ajustar el diseño del gráfico y el color del fondo
            fig.patch.set_facecolor('beige')
            ax.set_facecolor('beige')
            fig.tight_layout()
            
            # Crear un canvas para mostrar el gráfico en la ventana emergente
            canvas = FigureCanvasTkAgg(fig, master=popup)
            canvas.draw()
            canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
            
            # Ajustar el tamaño de la ventana emergente al tamaño del gráfico
            width, height = fig.get_size_inches() * fig.get_dpi()
            popup.geometry(f"{int(width)}x{int(height)}")
            
        except KeyError as e:
            messagebox.showerror("Error", f"Columna no encontrada: {e}")
    else:
        messagebox.showerror("Error", "Por favor, seleccione ambos parámetros para los ejes.")

