import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter as tk
from tkinter import Button, Label, messagebox, filedialog, ttk, Toplevel, Checkbutton, IntVar

def graficar_diagrama_hr(estrellas, ventana):
    temperaturas = [estrella.temperatura for estrella in estrellas]
    luminosidades = [estrella.luminosidad_secuencia() for estrella in estrellas]
    clasificaciones = [estrella.clasificacion_espectral() for estrella in estrellas]

    # Definir colores según la clasificación espectral
    colores = {
        'Clase O': 'slateblue',
        'Clase B': 'lightblue',
        'Clase A': 'white',
        'Clase F': 'palegoldenrod',
        'Clase G': 'yellow',
        'Clase K': 'orange',
        'Clase M': 'red',
        'Clase Desconocida': 'magenta'  # Agregar clase desconocida con color magenta
    }

    # Crear el gráfico
    fig, ax = plt.subplots(figsize=(7, 8), facecolor='black')
    fig.patch.set_facecolor('black')  # Establecer el fondo del gráfico en negro
    ax.set_facecolor('black')  # Establecer el fondo del gráfico en negro
    ax.tick_params(colors='white')  # Color de los ticks en blanco

    # Iterar sobre cada clase espectral y graficar puntos correspondientes
    for clase_espectral in colores.keys():
        indices = [i for i, c in enumerate(clasificaciones) if c == clase_espectral or (clase_espectral == 'Clase Desconocida' and c is None)]
        ax.scatter(
            [temperaturas[i] if temperaturas[i] is not None else 0 for i in indices],
            [luminosidades[i] for i in indices],
            color=colores[clase_espectral],
            label=clase_espectral,
            s=100,  # Tamaño de los puntos
            marker='*',  # Forma del marcador
            edgecolor='black',  # Color del borde
            linewidth=0.5,  # Ancho del borde
            alpha=0.8  # Transparencia
        )

    # Ajustes adicionales al gráfico
    ax.invert_xaxis()
    ax.set_yscale('log')
    ax.set_xlabel('Temperatura (K)', color='white', font="Times New Roman", size=15)
    ax.set_ylabel('Luminosidad (Luminosidad Solar)', color='white', font="Times New Roman", size=15)
    ax.legend(title='Clasificación Espectral', loc='lower left', fontsize=10, facecolor='white', edgecolor='white')
    ax.tick_params(axis='x', colors='white')
    ax.tick_params(axis='y', colors='white')

    # Anotación con el número de estrellas
    num_estrellas = len(estrellas)
    ax.set_title(f'Diagrama de Hertzsprung-Russell para Estrellas (Número de estrellas: {num_estrellas})', color='white', font="Times New Roman", size=16)

    # Asegurarse de que las líneas del eje sean visibles
    ax.spines['bottom'].set_color('white')
    ax.spines['top'].set_color('white')
    ax.spines['right'].set_color('white')
    ax.spines['left'].set_color('white')

    # Configurar el color de las etiquetas de los ejes
    ax.xaxis.label.set_color('white')
    ax.yaxis.label.set_color('white')

    # Configurar el color de las líneas de los ejes
    ax.tick_params(axis='x', colors='white')
    ax.tick_params(axis='y', colors='white')

    plt.tight_layout()
    plt.grid(True, which='both', linestyle='--', linewidth=0.5, color='gray')  # Agregar rejilla punteada

    # Ajustar el diseño del gráfico
    fig.tight_layout()

    # Crear un canvas para mostrar el gráfico en la ventana emergente
    canvas = FigureCanvasTkAgg(fig, master=ventana)
    canvas.draw()
    canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
