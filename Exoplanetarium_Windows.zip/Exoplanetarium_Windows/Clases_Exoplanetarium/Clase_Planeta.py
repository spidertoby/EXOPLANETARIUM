#!/usr/bin/env python
# coding: utf-8

import numpy as np

class Planeta:
    def __init__(self, nombre, masa, radio, semi_major_axis, inclinacion, excentricidad, argumento_periastron, temperatura, estrella_anfitriona):
        self.nombre = nombre
        self.masa = masa
        self.radio = radio
        self.semi_major_axis = semi_major_axis
        self.inclinacion = inclinacion
        self.excentricidad = excentricidad
        self.argumento_periastron = argumento_periastron
        self.temperatura = temperatura
        self.estrella_anfitriona = estrella_anfitriona
        
    def clasificacion_planetaria(self):
        if self.temperatura > 2000:
            return "Clase Alta"
        elif self.temperatura > 1000:
            return "Clase Media"
        else:
            return "Clase Baja"
