import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter as tk
from tkinter import Toplevel

def mapa_temperatura_estrellas(estrellas, ventana):
    # Extraer temperaturas y coordenadas (RA, DEC)
    ras = [estrella.ra for estrella in estrellas]
    decs = [estrella.dec for estrella in estrellas]
    temperaturas = [estrella.temperatura for estrella in estrellas]

    # Crear el gráfico de dispersión
    fig, ax = plt.subplots(figsize=(10, 6))
    scatter = ax.scatter(ras, decs, c=temperaturas, cmap='nipy_spectral_r', s=50, edgecolors='w')
    ax.set_xlabel('Ascensión Recta (RA)')
    ax.set_ylabel('Declinación (DEC)')
    ax.set_title('Mapa de Temperaturas de Estrellas')
    ax.grid(True)

    # Añadir barra de color
    cbar = fig.colorbar(scatter, ax=ax)
    cbar.set_label('Temperatura (K)')

    # Crear un canvas para mostrar el gráfico en la ventana emergente
    canvas = FigureCanvasTkAgg(fig, master=ventana)
    canvas.draw()
    canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

def mapa_temperatura_planetas(planetas, ventana):
    # Extraer temperaturas y coordenadas (RA, DEC) de las estrellas anfitrionas
    ras = [planeta.estrella_anfitriona.ra for planeta in planetas]
    decs = [planeta.estrella_anfitriona.dec for planeta in planetas]
    temperaturas = [planeta.temperatura for planeta in planetas]

    # Crear el gráfico de dispersión
    fig, ax = plt.subplots(figsize=(10, 6))
    scatter = ax.scatter(ras, decs, c=temperaturas, cmap='nipy_spectral_r', s=50, edgecolors='w')
    ax.set_xlabel('Ascensión Recta (RA)')
    ax.set_ylabel('Declinación (DEC)')
    ax.set_title('Mapa de Temperaturas de Planetas')
    ax.grid(True)

    # Añadir barra de color
    cbar = fig.colorbar(scatter, ax=ax)
    cbar.set_label('Temperatura (K)')

    # Crear un canvas para mostrar el gráfico en la ventana emergente
    canvas = FigureCanvasTkAgg(fig, master=ventana)
    canvas.draw()
    canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
