# Clase para representar una estrella
class Estrella:
    def __init__(self, nombre, masa, radio, temperatura, distancia, ra, dec):
        self.nombre = nombre
        self.masa = masa
        self.radio = radio
        self.temperatura = temperatura
        self.distancia = distancia
        self.ra = ra
        self.dec = dec

    
    def luminosidad_secuencia(self):
        """
        Calcula la luminosidad de la secuencia principal de la estrella con la fórmula L_ms = L_sun * (M/M_sun)**3.5
        """
        L_Sol = 3.828e26  # Luminosidad del Sol en vatios.
        M_Sol = 1.9884e30  # Masa del Sol en kg
        return L_Sol * (self.masa / M_Sol)**3.5
    
    def clasificacion_espectral(self):
        if self.temperatura is None:
            return 'Clase Desconocida'
        elif self.temperatura > 30000:
            return 'Clase O'
        elif self.temperatura > 10000:
            return 'Clase B'
        elif self.temperatura > 7500:
            return 'Clase A'
        elif self.temperatura > 6000:
            return 'Clase F'
        elif self.temperatura > 5200:
            return 'Clase G'
        elif self.temperatura > 3700:
            return 'Clase K'
        else:
            return 'Clase M'
        
