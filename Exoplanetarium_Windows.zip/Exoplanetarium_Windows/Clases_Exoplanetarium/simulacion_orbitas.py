#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter as tk
from tkinter import Button, Label, messagebox, filedialog, ttk, Toplevel, Checkbutton, IntVar

def datos_orbita_sistema(datos, star_name):
    star_planets = datos[datos['star_name'] == star_name]
    return star_planets

def calcular_orbita(semi_major_axis, eccentricity, omega, tperi, T, num=100):
    omega_rad = np.radians(omega)
    t = np.linspace(0, T, num)
    M = 2 * np.pi * (t - tperi) / T  # Removido el int()
    E = M.copy()
    for _ in range(100):
        E = M + eccentricity * np.sin(E)
    x = semi_major_axis * (np.cos(E) - eccentricity)
    y = semi_major_axis * np.sqrt(1 - eccentricity**2) * np.sin(E)
    x_rot = x * np.cos(omega_rad) - y * np.sin(omega_rad)
    y_rot = x * np.sin(omega_rad) + y * np.cos(omega_rad)
    return x_rot, y_rot

def calcular_baricentro(datos, star_name):
    star_planets = datos_orbita_sistema(datos, star_name)
    star_mass = star_planets.iloc[0]['star_mass']
    total_mass = star_mass + star_planets['mass'].sum()
    x_pos, y_pos = 0, 0
    for _, planet in star_planets.iterrows():
        semi_major_axis = planet['semi_major_axis']
        eccentricity = planet['eccentricity']
        omega = planet['omega']
        tperi = planet['tperi']
        planet_mass = planet['mass']
        distance_to_periapsis = semi_major_axis * (1 - eccentricity)
        x_orbit = distance_to_periapsis * np.cos(np.radians(omega))
        y_orbit = distance_to_periapsis * np.sin(np.radians(omega))
        x_pos += x_orbit * planet_mass
        y_pos += y_orbit * planet_mass
    x_pos /= total_mass
    y_pos /= total_mass
    return x_pos, y_pos

def calcular_posicion_estrella(datos, star_name):
    baricentro_x, baricentro_y = calcular_baricentro(datos, star_name)
    star_planets = datos_orbita_sistema(datos, star_name)
    star_mass = star_planets.iloc[0]['star_mass']
    total_mass = star_mass + star_planets['mass'].sum()
    star_x = -baricentro_x * (star_mass / total_mass)
    star_y = -baricentro_y * (star_mass / total_mass)
    return star_x, star_y

def obtener_limites_orbita(datos, star_name):
    star_planets = datos_orbita_sistema(datos, star_name)
    min_x, max_x, min_y, max_y = np.inf, -np.inf, np.inf, -np.inf
    
    for _, planet in star_planets.iterrows():
        x, y = calcular_orbita(
            semi_major_axis=float(planet['semi_major_axis']),
            eccentricity=float(planet['eccentricity']),
            omega=float(planet['omega']),
            tperi=float(planet['tperi']),
            T=float(planet['orbital_period']),
            num=1000
        )
        min_x = min(min_x, np.min(x))
        max_x = max(max_x, np.max(x))
        min_y = min(min_y, np.min(y))
        max_y = max(max_y, np.max(y))
    return min_x, max_x, min_y, max_y

def obtener_color_estrella(teff):
    if pd.isna(teff):
        return 'magenta'
    elif teff > 28000:
        return 'slateblue'
    elif teff > 10000:
        return 'lightblue'
    elif teff > 7500:
        return 'white'
    elif teff > 6000:
        return 'palegoldenrod'
    elif teff > 5000:
        return 'yellow'
    elif teff > 3500:
        return 'orange'
    else:
        return 'red'

def obtener_clase_estrella(teff):
    if pd.isna(teff):
        return 'Desconocida'
    elif teff > 28000:
        return 'O'
    elif teff > 10000:
        return 'B'
    elif teff > 7500:
        return 'A'
    elif teff > 6000:
        return 'F'
    elif teff > 5000:
        return 'G'
    elif teff > 3500:
        return 'K'
    else:
        return 'M'

def animar_orbitas(datos, star_name, root):
    star_planets = datos_orbita_sistema(datos, star_name)
    
    if star_planets.empty:
        print(f"No se encontraron datos para la estrella {star_name}.")
        return
    
    popup = Toplevel(root)
    popup.title("Simulacion Orbitas")
    popup.configure(bg="gray26")
    
    fig, ax = plt.subplots(figsize=(10, 10))
    
    min_x, max_x, min_y, max_y = obtener_limites_orbita(datos, star_name)
    
    if np.isinf([min_x, max_x, min_y, max_y]).any() or np.isnan([min_x, max_x, min_y, max_y]).any():
        message = f"Los límites de la órbita contienen valores NaN o Inf para la estrella {star_name}."
        messagebox.showwarning("Advertencia", message)
        return

    margin = 0.2
    min_x -= margin
    max_x += margin
    min_y -= margin
    max_y += margin
    
    star_x, star_y = calcular_posicion_estrella(datos, star_name)
    star_teff = star_planets.iloc[0]['star_teff']
    star_color = obtener_color_estrella(star_teff)
    star_class = obtener_clase_estrella(star_teff)
    
    ax.plot(star_x, star_y, 'o', label='Estrella Anfitriona', color=star_color, markersize=12, zorder=1)
    
    info_estrella = f'Temperatura: {star_teff} K\nClase Espectral: {star_class}'
    ax.legend(title=info_estrella, loc='upper right', fontsize=10, facecolor='white', edgecolor='white')
    
    planet_lines = []
    planet_markers = []
    for _, planet in star_planets.iterrows():
        x, y = calcular_orbita(
            semi_major_axis=planet['semi_major_axis'],
            eccentricity=planet['eccentricity'],
            omega=planet['omega'],
            tperi=planet['tperi'],
            T=planet['orbital_period'],
            num=1000
        )
        line, = ax.plot(x, y, label=planet['name'], zorder=1)
        planet_lines.append(line)
        marker, = ax.plot([], [], 'o', color=line.get_color(), zorder=1)
        planet_markers.append(marker)
    
    def init():
        ax.set_xlim(min_x, max_x)
        ax.set_ylim(min_y, max_y)
        ax.set_xlabel('Distancia (AU)')
        ax.set_ylabel('Distancia (AU)')
        ax.set_title(f'Órbitas de los exoplanetas alrededor de [{star_name}]')
        ax.legend()
        ax.grid(True)
        return planet_markers
    
    def update(frame):
        for marker, (_, planet) in zip(planet_markers, star_planets.iterrows()):
            x, y = calcular_orbita(
                semi_major_axis=planet['semi_major_axis'],
                eccentricity=planet['eccentricity'],
                omega=planet['omega'],
                tperi=planet['tperi'],
                T=planet['orbital_period'],
                num=1000
            )
            marker.set_data(x[:frame+1], y[:frame+1])
        return planet_markers
    
    ani = FuncAnimation(fig, update, frames=1000, init_func=init, blit=True, interval=50, repeat=True)

    canvas = FigureCanvasTkAgg(fig, master= popup)
    canvas.draw()
    canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)
    

