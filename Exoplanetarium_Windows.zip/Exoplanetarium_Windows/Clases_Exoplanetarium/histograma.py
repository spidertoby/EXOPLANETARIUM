#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter as tk
from tkinter import Toplevel

def plot_histograma_grafico(root, datos, x_param_es, tipo_param, param_map_es_to_en):
    opciones_estrellas = ["star_mass", "star_radius", "star_distance", "star_metallicity", "star_age",
                          "star_teff", "ra", "dec", "mag_v", "mag_i", "mag_j", "mag_h", "mag_k"]
    
    ejexs = {"star_mass":"Masa Estelar [masaSol]", "star_radius":"Radio de Estrellas [radioSol]", 
             "star_distance":"Distancia a Estrellas [pc]", "star_metallicity":"Metalicidad de Estrellas", 
             "star_age":"Edad de Estrellas [Gyr]", "star_teff":"Temperatura Efectiva [K]", 
             "ra":"Ascensión Recta [grados]", "dec":"Declinación [grados]", 
             "mag_v":"Magnitud V", "mag_i":"Magnitud I", "mag_j":"Magnitud J", "mag_h":"Magnitud H", 
             "mag_k":"Magnitud K"}
    
    opciones_planetas = ["mass", "mass_sini", "radius", "orbital_period", "semi_major_axis", "eccentricity", 
                         "inclination", "angular_distance", "discovered", "omega", "tperi", "tconj", "tzero_tr", 
                         "tzero_tr_sec", "lambda_angle", "impact_parameter", "tzero_vr", "k", "temp_calculated", 
                         "temp_measured", "hot_point_lon", "geometric_albedo", "log_g", "detection_type"]
    
    ejexp = {"mass":"Masa Exoplanetas [masaJup]", "mass_sini":"Masa Exoplanetas*sin(i) [masaJup]", 
             "radius":"Radio Exoplanetas [radioJup]", "orbital_period":"Periodo Orbital [día]", 
             "semi_major_axis":"Eje Semimayor [UA]", "eccentricity":"Eccentricidad Órbita", 
             "inclination":"Inclinación Órbita [grados]", "angular_distance":"Distancia Angular [arcsec]", 
             "discovered":"Año de Descubrimiento", "omega":"Argumento Periastrón [grados]", 
             "tperi":"Época Periastrón [día]", "tconj":"Fecha de Conjunción [día]", 
             "tzero_tr":"Tránsito Primario [día]", "tzero_tr_sec":"Tránsito Secundario [día]", 
             "lambda_angle":"Ángulo de Proyección en el Cielo (giro orbital planetario-giro rotacional estelar) [grados]", 
             "impact_parameter":"Parámetro Impacto b", "tzero_vr":"Tiempo Velocidad Radial Cero [día]", 
             "k":"Semiamplitud de Velocidad K [m.s-1]", "temp_calculated":"Temperatura Calculada [K]", 
             "temp_measured":"Temperatura Medida [K]", "hot_point_lon":"Longitud Punto más Caliente [grados]", 
             "geometric_albedo":"Albedo Geométrico", "log_g":"log(g)"}
    
    x_param = param_map_es_to_en.get(x_param_es)
    
    if tipo_param == "estrellas" and x_param in opciones_estrellas:
        if x_param not in datos.columns:
            raise KeyError(f"La columna {x_param} no existe en los datos")
        
        data = datos[["star_name", x_param]].dropna().drop_duplicates(subset='star_name')
        
        if x_param == "star_metallicity":
            data = data[data[x_param] <= 1]
        
        popup = Toplevel(root)
        popup.title("Histograma")
        popup.configure(bg="gray26")
        
        fig, ax = plt.subplots()
        fig.patch.set_facecolor("beige")
        ax.hist(data[x_param], bins=20, edgecolor="w", color="saddlebrown")
        
        plt.title(f"Histograma de {x_param_es} vs Número de Estrellas")
        plt.ylabel("Número de Estrellas")
        plt.xlabel(ejexs.get(x_param, x_param))
        plt.grid(color="k", ls="--")
        ax.set_facecolor("beige")
    
    elif tipo_param == "exoplanetas" and x_param in opciones_planetas:
        if x_param not in datos.columns:
            raise KeyError(f"La columna {x_param} no existe en los datos")
        
        data = datos[["name", x_param]].dropna()
        
        popup = Toplevel(root)
        popup.title("Histograma")
        popup.configure(bg="gray26")
        
        fig, ax = plt.subplots()
        fig.patch.set_facecolor("beige")
        
        if x_param == "detection_type":
            metodo_counts = data["detection_type"].value_counts()
            ax.bar(metodo_counts.index, metodo_counts.values, color="saddlebrown", edgecolor="k")
            plt.title("Método de Descubrimiento")
            plt.ylabel("Número de Exoplanetas")
            plt.xticks(rotation=45, ha="right")
        else:
            ax.hist(data[x_param], bins=20, edgecolor="w", color="saddlebrown")
            plt.title(f"Histograma de {x_param_es} vs Número de Exoplanetas")
            plt.ylabel("Número de Exoplanetas")
            plt.xlabel(ejexp.get(x_param, x_param))
        
        plt.grid(color="k", ls="--")
        ax.set_facecolor("beige")
    else:
        raise ValueError("Opción no disponible, por favor ingrese una opción válida")
    
    canvas = FigureCanvasTkAgg(fig, master=popup)
    canvas.draw()
    canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
    
    width, height = fig.get_size_inches() * fig.get_dpi()
    popup.geometry(f"{int(width)}x{int(height)}")

