#Importación de librerías
import os
import sys
import cv2
import io
import time
import datetime
import threading
import numpy as np
import pandas as pd
import tkinter as tk
import matplotlib.pyplot as plt
from pathlib import Path
from PIL import Image, ImageTk 
from tkinter import Button, Label, messagebox, filedialog, ttk, Toplevel, Checkbutton, IntVar
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.animation import FuncAnimation
from PIL import Image, ImageTk

#Registramos la ruta de acceso relativa a las carpetas del proyecto
try:
    #Intentamos obtener la ruta usando file (funciona en scripts)
    current_dir = os.path.dirname(os.path.abspath(__file__))
except NameError:
    #Si file no está definido, usamos el directorio de trabajo actual
    current_dir = os.getcwd()

#Definimos la ruta del directorio padre
parent_dir = os.path.dirname(current_dir)

#Añadimos la ruta del directorio padre a sys.path
sys.path.append(parent_dir)

#Importación de módulos utilizados
from Clases_Exoplanetarium.Clase_Estrella import Estrella
from Clases_Exoplanetarium.Clase_Planeta import Planeta
from Clases_Exoplanetarium.diagrama_hr import graficar_diagrama_hr
from Clases_Exoplanetarium.scatter_plot import plot_scatter
from Clases_Exoplanetarium.histograma import plot_histograma_grafico
from Clases_Exoplanetarium.simulacion_orbitas import datos_orbita_sistema, calcular_orbita, calcular_baricentro, calcular_posicion_estrella, obtener_limites_orbita, obtener_color_estrella, obtener_clase_estrella, animar_orbitas
from Clases_Exoplanetarium.mapas_temperatura import mapa_temperatura_estrellas, mapa_temperatura_planetas


#Siguiente sección; Carga y Lectura de Datos
#Inicializamos las variables globales para los datos
datos = None
progress_bar = None
label_percent = None
label_carga = None
estrellas = None
planetas = None

#Siguiente sección; Carga y Lectura de Datos
#Inicializamos las variables globales para los datos
def descargar_datos(url, download_dir, label_status, combobox_x, combobox_y, ventana_carga, progress_var):
    """Descarga los datos de la URL proporcionada y los guarda en el directorio de descarga especificado.

    Args:
        url (link): URL de la página web que contiene los datos a descargar.
        download_dir (directorio): Directorio donde se guardarán los datos descargados.
        label_status (etiqueta): Etiqueta para mostrar el estado de la descarga.
        combobox_x (Tkinter Combobox): ComboBox que guarda los elementos necesarios para el eje X.
        combobox_y (Tkinter Combobox): ComboBox que guarda los elementos necesarios para el eje Y.
        ventana_carga (Tkinter Frame): Ventana donde se mostrará la barra de progreso.
        progress_var (progress var): Barra de progeso de la carga de datos.
    
    Returns:
        None
    """    
   
    chrome_options = Options()
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": download_dir,
        "download.prompt_for_download": False,
        "safebrowsing.enabled": True,
        "profile.default_content_settings.popups": 0,
        "plugins.always_open_pdf_externally": True
    })
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--window-size=1920x1080")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    script_dir = os.path.dirname(os.path.abspath(__file__))
    chromedriver_path = os.path.join(script_dir, "chrome_driver", "chromedriver.exe")
    service = Service(chromedriver_path)
    driver = webdriver.Chrome(service=service, options=chrome_options)

    archivo_descargado = os.path.join(download_dir, "download.csv")
    
    #Verificamos si es que el archivo ya existía previamente; en caso de que sí, lo eliminamos
    if os.path.exists(archivo_descargado):
        os.remove(archivo_descargado)

    try:
        driver.get(url)
        wait = WebDriverWait(driver, 20)
        print(f"Accediendo a la URL: {url}") #Mensaje de depuración para verificar la URL
        boton_descarga = wait.until(EC.element_to_be_clickable((By.XPATH, '//*[@id="downloads-section"]/div/div/div[1]/a')))
        print("Botón de descarga encontrado y clickeado.") #Mensaje de depuración para verificar el botón de descarga
        boton_descarga.click()

        file_size = 0
        progress_var.set(0)
        frame_central.update_idletasks()
        
        while True:
            time.sleep(0.5)
            files = os.listdir(download_dir)
            print(f"Archivos en el directorio de descargas: {files}")

            crdownload_files = [f for f in files if f.endswith(".crdownload")]
            if crdownload_files:
                file_path = os.path.join(download_dir, crdownload_files[0])
                if os.path.exists(file_path):
                    new_size = os.path.getsize(file_path)
                    if new_size != file_size:
                        file_size = new_size
                        print(f"Tamaño del archivo .crdownload: {file_size} bytes") #Mensaje de depuración para verificar el tamaño del archivo
                        estimated_total_size = max(file_size, 3078 * 1024)
                        progress_percentage = min(100, (file_size / estimated_total_size) * 100)
                        progress_var.set(progress_percentage)
                        label_percent.config(text=f"{progress_percentage:.2f}%")
                        frame_central.update_idletasks()
            else:
                if os.path.exists(archivo_descargado):
                    file_size = os.path.getsize(archivo_descargado)
                    print(f"Tamaño del archivo descargado: {file_size} bytes")
                    progress_var.set(100)
                    label_percent.config(text="100%")
                    frame_central.update_idletasks()
                break

    except Exception as e:
        print(f"Error durante la descarga: {e}")
    finally:
        driver.quit()
    if os.path.exists(archivo_descargado):
        try:
            with open(archivo_descargado, 'r', encoding='utf-8') as file:
                datos_csv = file.read()
            cargar_datos(datos_csv, label_status, combobox_x, combobox_y)
        except FileNotFoundError:
            messagebox.showerror("Error", "El archivo descargado no se encontró.")
        except Exception as e:
            messagebox.showerror("Error", f"Error al cargar el archivo: {e}")
    else:
        messagebox.showerror("Error", "El archivo no se descargó correctamente.")

#Función para cargar los datos
def cargar_datos(datos_csv, label_status, combobox_x, combobox_y):
    """Función para cargar los datos de un archivo CSV y procesarlos.

    Args:
        datos_csv (archivo csv): Archivo CSV con los datos a cargar.
        label_status (etiqueta/label): Etiqueta para mostrar el estado de la carga.
        combobox_x (Tkinter Combobox): ComboBox que guarda los elementos necesarios para el eje X.
        combobox_y (Tkinter Combobox): ComboBox que guarda los elementos necesarios para el eje Y.  
    
    Returns:
        None
    """
    global datos, estrellas, planetas
    if datos_csv:
        try:
            datos = pd.read_csv(io.StringIO(datos_csv))
            label_status.config(text="¡Datos cargados exitosamente!", fg="#74D153")
            combobox_x['values'] = list(param_map_es_to_en.keys())
            combobox_y['values'] = list(param_map_es_to_en.keys())
            print("Columnas cargadas:", datos.columns)
            llenar_combobox() #Llamamos la función para llenar el combobox con los datos leídos

            estrellas = [] 
            #Inicializamos la lista de estrellas que vamos llenando con los datos leídos de las estrellas
            for index, row in datos.iterrows():
                estrella = Estrella(
                    nombre=row['star_name'],
                    masa=row['star_mass'],
                    radio=row['star_radius'],
                    temperatura=row['star_teff'],
                    distancia=row['star_distance'],
                    ra=row['ra'],
                    dec=row['dec']
                )
                estrellas.append(estrella)

            planetas = []
            #Inicializamos la lista de planetas que vamos llenando con los datos leídos de los planetas
            for index, row in datos.iterrows():
                estrella_anfitriona = next((e for e in estrellas if e.nombre == row['star_name']), None)
                if estrella_anfitriona:
                    planeta = Planeta(
                        nombre=row['name'],
                        masa=row['mass'],
                        radio=row['radius'],
                        semi_major_axis=row['semi_major_axis'],
                        inclinacion=row['inclination'],
                        excentricidad=row['eccentricity'],
                        argumento_periastron=row['omega'],
                        temperatura=row['temp_calculated'],
                        estrella_anfitriona=estrella_anfitriona
                    )
                    planetas.append(planeta)

        except KeyError as e:
            label_status.config(text="No se pudieron cargar los datos.", fg="red")
            messagebox.showerror("Error", f"Columna no encontrada en el archivo CSV: {e}")
        except Exception as e:
            label_status.config(text="No se pudieron cargar los datos.", fg="red")
            messagebox.showerror("Error", f"Error al cargar y procesar datos: {e}")

#Función para llenar los combobox
def llenar_combobox():
    """Función para llenar los combobox con los datos leídos del archivo CSV.
    """
    if datos is not None and "star_name" in datos.columns:
        combo_box_estrellas["values"] = datos["star_name"].dropna().unique().tolist()
    else:
        print("Error: 'datos' no está correctamente inicializado o la columna 'star_name' no existe.")

#Función para cargar los datos existentes e iniciar la descarga si es necesario
def iniciar_descarga():
    """Función para iniciar la descarga de los datos si no existen o cargar los datos existentes.

    Returns:
        None
    """ 
    global progress_bar, label_percent, label_carga

    #Eliminamos la barra de progreso existente, la etiqueta de porcentaje y la etiqueta de carga si ya existen
    if progress_bar:
        progress_bar.destroy()
    if label_percent:
        label_percent.destroy()
    if label_carga:
        label_carga.destroy()

    url = "https://exoplanet.eu/catalog/#" #URL de la página web de la que se descargarán los datos
    current_dir = os.getcwd()
    download_dir = os.path.join(current_dir, "Testeo_Descarga") #Directorio donde se guardarán los datos descargados
    archivo_descargado = os.path.join(download_dir, "download.csv")
    os.makedirs(download_dir, exist_ok=True)

    #Verificamos si el archivo ya existe, en cuyo caso preguntamos al usuario si desea descargarlo nuevamente o usar los datos antiguos
    if os.path.exists(archivo_descargado):
        fecha_modificacion = datetime.datetime.fromtimestamp(os.path.getmtime(archivo_descargado))
        mensaje = f"Ya existe un archivo descargado el {fecha_modificacion.strftime('%Y-%m-%d %H:%M:%S')}. ¿Deseas descargarlo nuevamente?"
        respuesta = messagebox.askyesno("Archivo Existente", mensaje)
        if not respuesta:
            procesar_datos_existentes(archivo_descargado)
            return
    
    label_status.config(text="")
    label_carga = Label(frame_central, text="Cargando datos, por favor espera . . .", bg="black", fg="#74D153", font=("Times New Roman", 15, "bold"))
    label_carga.grid(row=2, column=0, columnspan=2, pady=20)
    
    style = ttk.Style()
    style.theme_use('default')
    style.configure("Custom.Horizontal.TProgressbar",
                    troughcolor='black',
                    background='#74D153',
                    thickness=20)          

    #Creamos la barra de progreso utilizando el estilo personalizado
    progress_var = IntVar()
    progress_bar = ttk.Progressbar(frame_central, orient="horizontal", length=300, mode="determinate", 
                                variable=progress_var, maximum=100, style="Custom.Horizontal.TProgressbar")
    progress_bar.grid(row=3, column=0, columnspan=2, pady=20)
    label_percent = Label(frame_central, text="0%", bg="black", fg="#74D153", font=("Times New Roman", 15, "bold"))
    label_percent.grid(row=4, column=0, columnspan=2, pady=20)

    threading.Thread(target=descargar_datos, args=(url, download_dir, label_status, combobox_x, combobox_y, frame_central, progress_var)).start()

#Función para procesar los datos existentes
def procesar_datos_existentes(archivo_descargado):
    """Función para procesar los datos existentes si el archivo ya ha sido descargado.

    Args:
        archivo_descargado (archivo csv): Archivo CSV descargado previamente.
    
    Returns:
        None
    """
    try:
        with open(archivo_descargado, 'r', encoding='utf-8') as file:
            datos_csv = file.read()
        cargar_datos(datos_csv, label_status, combobox_x, combobox_y)
    except FileNotFoundError:
        messagebox.showerror("Error", "El archivo descargado no se encontró.")
    except Exception as e:
        messagebox.showerror("Error", f"Error al cargar el archivo: {e}")

#Función para cargar los datos existentes
def procesar_datos_existentes(archivo_descargado):
    """Función para procesar los datos existentes si el archivo ya ha sido descargado, mostrando una barra de progreso.

    Args:
        archivo_descargado (archivo csv): Archivo CSV descargado previamente.

    Returns:
        None
    """
    global progress_bar, label_percent, label_carga

    #Eliminamos la barra de progreso existente, la etiqueta de porcentaje y la etiqueta de carga si ya existen
    if progress_bar:
        progress_bar.destroy()
    if label_percent:
        label_percent.destroy()
    if label_carga:
        label_carga.destroy()

    label_carga = Label(frame_central, text="Cargando datos antiguos, por favor espera . . .", bg="black", fg="green", font=("Times New Roman", 15, "bold"))
    label_carga.grid(row=2, column=0, columnspan=2, pady=20)
    style = ttk.Style()
    style.theme_use('default')
    style.configure("Custom.Horizontal.TProgressbar",
                    troughcolor='black',
                    background='#74D153',
                    thickness=20)      

    progress_var = IntVar()
    progress_bar = ttk.Progressbar(frame_central, orient="horizontal", length=300, mode="determinate", variable=progress_var, maximum=100,  style="Custom.Horizontal.TProgressbar")
    progress_bar.grid(row=3, column=0, columnspan=2, pady=20)
    label_percent = Label(frame_central, text="0%", bg="black", fg="green", font=("Times New Roman", 15, "bold"))
    label_percent.grid(row=4, column=0, columnspan=2, pady=20)

    threading.Thread(target=cargar_datos_existentes, args=(archivo_descargado, progress_var)).start()

#Función para cargar los datos existentes con una barra de progreso
def cargar_datos_existentes(archivo_descargado, progress_var):
    """Función para cargar los datos existentes si el archivo ya ha sido descargado, mostrando una barra de progreso.

    Args:
        archivo_descargado (archivo csv): Archivo CSV descargado previamente.
        progress_var (progress var): Barra de progreso para mostrar el progreso de la carga.
    
    Returns:
        None
    """
    try:
        with open(archivo_descargado, 'r', encoding='utf-8') as file:
            datos_csv = file.read()
        
        #Simulamos la actualización del progreso
        file_size = len(datos_csv)
        read_size = 0
        chunk_size = 1024
        for i in range(0, file_size, chunk_size):
            time.sleep(0.01)
            read_size += chunk_size
            progress_percentage = min(100, (read_size / file_size) * 100)
            progress_var.set(progress_percentage)
            label_percent.config(text=f"{progress_percentage:.2f}%")
            frame_central.update_idletasks()
        #Cuando el progreso llega a 100%, ocultamos o destruimos la etiqueta de carga, la barra de progreso y la etiqueta de porcentaje
        if progress_percentage >= 100:
            label_carga.destroy()
            label_percent.destroy()
            progress_bar.destroy()

        cargar_datos(datos_csv, label_status, combobox_x, combobox_y)
    except FileNotFoundError:
        messagebox.showerror("Error", "El archivo descargado no se encontró.")
    except Exception as e:
        messagebox.showerror("Error", f"Error al cargar el archivo: {e}")


#Siguiente sección; Creación y manejo de ventanas secundarias
def mostrar_pantalla_principal():
    """Función para mostrar la pantalla principal y ocultar las demás.
    """
    frame_principal.grid(row=0, column=0, sticky="nsew")
    frame_secundario.grid_forget()
    frame_scatter.grid_forget()
    frame_diagrama.grid_forget()
    frame_hist.grid_forget()
    frame_orb.grid_forget()
    frame_mapa.grid_forget()

def mostrar_pantalla_secundaria():
    """Función para mostrar la pantalla secundaria y ocultar las demás.
    """
    frame_principal.grid_forget()
    frame_secundario.grid(row=0, column=0, sticky="nsew")
    frame_scatter.grid_forget()
    frame_diagrama.grid_forget()
    frame_hist.grid_forget()
    frame_orb.grid_forget()
    frame_mapa.grid_forget()

def mostrar_pantalla_scatter():
    """Función para mostrar la pantalla perteneciente al gráfico Scatter Plot y ocultar las demás.
    """
    frame_principal.grid_forget()
    frame_secundario.grid_forget()
    frame_scatter.grid(row=0, column=0, sticky="nsew")
    frame_diagrama.grid_forget()
    frame_hist.grid_forget()
    frame_orb.grid_forget()
    frame_mapa.grid_forget()

def mostrar_pantalla_diagrama():
    """Función para mostrar la pantalla perteneciente al gráfico Diagrama H-R y ocultar las demás.
    """
    frame_principal.grid_forget()
    frame_secundario.grid_forget()
    frame_scatter.grid_forget()
    frame_diagrama.grid(row=0, column=0, sticky="nsew")
    frame_hist.grid_forget()
    frame_orb.grid_forget()
    frame_mapa.grid_forget()

def mostrar_pantalla_histograma():
    """Función para mostrar la pantalla perteneciente al gráfico Histograma y ocultar las demás.
    """
    frame_principal.grid_forget()
    frame_secundario.grid_forget()
    frame_scatter.grid_forget()
    frame_diagrama.grid_forget()
    frame_hist.grid(row=0, column=0, sticky="nsew")
    frame_orb.grid_forget()
    frame_mapa.grid_forget()

def mostrar_pantalla_orbita():
    """Función para mostrar la pantalla perteneciente al gráfico Simulación de Órbitas y ocultar las demás.
    """
    frame_principal.grid_forget()
    frame_secundario.grid_forget()
    frame_scatter.grid_forget()
    frame_diagrama.grid_forget()
    frame_hist.grid_forget()
    frame_orb.grid(row=0, column=0, sticky="nsew")
    frame_mapa.grid_forget()

def mostrar_pantalla_mapa():
    """Función para mostrar la pantalla perteneciente al gráfico Mapa de Temperatura y ocultar las demás.
    """
    frame_principal.grid_forget()
    frame_secundario.grid_forget()
    frame_scatter.grid_forget()
    frame_diagrama.grid_forget()
    frame_hist.grid_forget()
    frame_orb.grid_forget()
    frame_mapa.grid(row=0, column=0, sticky="nsew")

#Creamos las ventanas secundarias de la aplicación pertenecientes a cada gráfico
def on_plot_scatter():
    """Función para mostrar la ventana del gráfico Scatter Plot.
    """
    global datos
    if datos is None:
        messagebox.showerror("Error", "Primero debe cargar los datos.")
        return
    x_param_es = combobox_x.get()
    y_param_es = combobox_y.get()
    color_param_es = combobox_color.get()
    mostrar_temperatura = var_mostrar_temperatura.get() == 1
    plot_scatter(root, datos, x_param_es, y_param_es, param_map_es_to_en, color_param_es, mostrar_temperatura)

def plot_diagrama_hr():
    """Función para mostrar la ventana del gráfico Diagrama H-R.
    """
    global estrellas
    if estrellas is None:
        messagebox.showerror("Error", "Primero debe cargar los datos.")
        return
    try:
        popup = Toplevel(root)
        popup.title("Diagrama HR")
        popup.configure(bg="gray26")
        graficar_diagrama_hr(estrellas, popup)
    except KeyError as e:
        messagebox.showerror("Error", f"Columna no encontrada: {e}")

def plot_histograma():
    """Función para mostrar la ventana del gráfico Histograma.
    """
    global datos
    if datos is None:
        messagebox.showerror("Error", "Primero debe cargar los datos.")
        return
    x_param_es = combobox_x_hist.get()
    tipo_param = combobox_tipo_hist.get().lower()
    try:
        plot_histograma_grafico(root, datos, x_param_es, tipo_param, param_map_es_to_en)
    except (KeyError, ValueError) as e:
        messagebox.showerror("Error", str(e))

def actualizar_opciones_histograma(event):
    """Función para actualizar las opciones del combobox de eje X en el gráfico Histograma.

    Args:
        event (event): Evento que activa la función.
    
    Returns:
        None
    """
    tipo_param = combobox_tipo_hist.get().lower()
    if tipo_param == "estrellas":
        combobox_x_hist['values'] = [key for key, value in param_map_es_to_en.items() if value in opciones_estrellas]
    elif tipo_param == "exoplanetas":
        combobox_x_hist['values'] = [key for key, value in param_map_es_to_en.items() if value in opciones_planetas]
    else:
        messagebox.showerror("Error", "Tipo de histograma no válido")


#Definimos las opciones de estrellas y planetas para el gráfico Simulación de Órbitas
opciones_estrellas = ["star_mass", "star_radius", "star_distance", "star_metallicity", "star_age",
                      "star_teff", "ra", "dec", "mag_v", "mag_i", "mag_j", "mag_h", "mag_k"]

opciones_planetas = ["mass", "mass_sini", "radius", "orbital_period", "semi_major_axis", "eccentricity", 
                     "inclination", "angular_distance", "discovered", "omega", "tperi", "tconj", "tzero_tr", 
                     "tzero_tr_sec", "lambda_angle", "impact_parameter", "tzero_vr", "k", "temp_calculated", 
                     "temp_measured", "hot_point_lon", "geometric_albedo", "log_g", "detection_type"]
orbital_data = pd.DataFrame(datos, columns=["star_name", "star_mass", "name", "mass", "orbital_period", "semi_major_axis", "eccentricity", "omega", "tperi", "star_teff"])
orbital_data_clean = orbital_data.dropna(subset=["star_name", "star_mass", "name", "mass", "orbital_period", "semi_major_axis", "eccentricity", "omega", "tperi"]) # Eliminar valores nulos relevantes
star_names = pd.DataFrame(orbital_data_clean, columns=["star_name"])

def mostrar_sistemas_planetarios():
    """Función para mostrar los sistemas planetarios.
    """
    global combo_box
    if combo_box.winfo_viewable():
        combo_box.place_forget()
    else:
        combo_box['values'] = star_names['star_name'].unique().tolist()
        combo_box.place(x=110, y=300)

def graficar_orbitas():
    """Función para graficar las órbitas de los sistemas planetarios.
    """
    star_name = combo_box.get()
    fig, ani = animar_orbitas(star_name)
    
    if fig is not None:
        popup = Toplevel(root)
        popup.title("Simulación Órbitas")
        popup.configure(bg="gray26")
        canvas = FigureCanvasTkAgg(fig, master=popup)
        canvas.draw()
        canvas.get_tk_widget().grid(row=0, column=0, sticky="nsew")
        popup.grid_rowconfigure(0, weight=1)
        popup.grid_columnconfigure(0, weight=1)

def datos_orbita_sistema(star_name):
    """Función para obtener los datos de la órbita de un sistema planetario.

    Args:
        star_name (lista): Lista de nombres de estrellas anfitrionas.

    Returns:
        lista: Lista de los nombres de las estrellas anfitrionas con respecto a los datos de los planetas
    """
    star_planets = datos[datos['star_name'] == star_name]
    return star_planets

#Función para mostrar los sistemas planetarios
def mostrar_sistemas_planetarios():
    """Función para mostrar los sistemas planetarios.
    """
    global combo_box
    if combo_box.winfo_viewable():
        combo_box.place_forget()
    else:
        combo_box['values'] = datos['star_name'].unique().tolist()
        combo_box.place(x=110, y=300)

def graficar_orbitas():
    """Función para graficar las órbitas de los sistemas planetarios.
    """
    star_name = combo_box_estrellas.get()
    animar_orbitas(datos, star_name, root)



def plot_mapa_estrella():
    """Función para mostrar el gráfico Mapa de Temperatura de las estrellas anfitrionas, 
    donde se verifica si los datos de la lista de estrellas han sido cargados.
    """
    global estrellas
    if not estrellas:
        messagebox.showerror("Error", "Primero debe cargar los datos.")
        return
    try:
        popup = Toplevel(root)
        popup.title("Mapa de Temperatura Superficial de Estrellas Anfitrionas")
        popup.configure(bg="gray26")
        mapa_temperatura_estrellas(estrellas, popup)
    except KeyError as e:
        messagebox.showerror("Error", f"Columna no encontrada: {e}")

def plot_mapa_planeta():
    """Función para mostrar el gráfico Mapa de Temperatura de los exoplanetas.
    """
    global planetas
    if not planetas:
        messagebox.showerror("Error", "Primero debe cargar los datos.")
        return
    try:
        popup = Toplevel(root)
        popup.title("Mapa de Temperatura Superficial de Exoplanetas")
        popup.configure(bg="gray26")
        mapa_temperatura_planetas(planetas, popup)
    except KeyError as e:
        messagebox.showerror("Error", f"Columna no encontrada: {e}")


#Siguiente sección; Creación de la interfaz gráfica visual
root = tk.Tk()
root.title("EXOPLANETARIUM")
root.geometry("1280x720")
root.configure(bg="black")
root.resizable(True, True)

#Definimos los parámetros para la implementación del fondo de pantalla
directorio_actual = os.path.dirname(__file__)
ruta_imagen = os.path.join(directorio_actual, 'fondo.png') #Definimos la ruta relativa de la imagen de fondo
image = Image.open(ruta_imagen)
def ajustar_imagen(event=None):
    """Función para ajustar la imagen de fondo al tamaño del canvas.

    Args:
        event (event): Evento que activa la función

    Returns:
        None
    """
    nuevo_ancho = canvas.winfo_width()
    nuevo_alto = canvas.winfo_height()
    imagen_redimensionada = image.resize((nuevo_ancho, nuevo_alto), Image.LANCZOS)

    bg_image = ImageTk.PhotoImage(imagen_redimensionada) #Convertimos la imagen a un formato compatible con Tkinter
    canvas.delete("all") #Limpiamos el canvas antes de agregar la imagen
    canvas.create_image(0, 0, image=bg_image, anchor="nw")
    canvas.bg_image = bg_image


#Creamos el frame principal
frame_principal = tk.Frame(root, bg="black")
frame_principal.grid(row=0, column=0, sticky="nsew")

root.grid_rowconfigure(0, weight=1)
root.grid_columnconfigure(0, weight=1)
canvas = tk.Canvas(frame_principal, bg="black", highlightthickness=0)
canvas.grid(row=0, column=0, sticky="nsew")

frame_principal.grid_rowconfigure(0, weight=1)
frame_principal.grid_columnconfigure(0, weight=1)

def inicializar_fondo():
    """Función que inicializa el fondo de la pantalla principal.
    """
    root.update_idletasks()
    ajustar_imagen()

inicializar_fondo()
canvas.bind("<Configure>", ajustar_imagen)

def mostrar_mensaje():
    """Función que muestra un mensaje informativo al hacer click.
    """
    ventana = tk.Toplevel()
    ventana.title("Info. Cargar Datos")
    ventana.configure(bg="#bf74ef")
    
    mensaje = tk.Label(ventana, text="Cuando haces clic en 'Cargar Datos', puedes cargar un archivo antiguo o también elegir uno actualizado, ya que nuestra aplicación descarga automáticamente información de 'Encyclopaedia of Exoplanetary Systems'. Ésta enciclopedia proporciona datos actualizados y detallados sobre exoplanetas y sus sistemas, garantizando que trabajes con información precisa y confiable para tus análisis y gráficos.", wraplength=400, bg="#bf74ef")
    mensaje.grid(row=0, column=0, padx=20, pady=20)

    ventana.update_idletasks()
    ventana.geometry(f"+{root.winfo_x() + (root.winfo_width() // 2) - (ventana.winfo_width() // 2)}+{root.winfo_y() + (root.winfo_height() // 2) - (ventana.winfo_height() // 2)}")


#Creamos un frame central para contener los elementos centrales
frame_central = tk.Frame(frame_principal, bg="black")
frame_central.place(relx=0.5, rely=0.5, anchor='center')

canvas_boton_redondo = tk.Canvas(frame_central, width=40, height=40, bg="black", highlightthickness=0)
canvas_boton_redondo.grid(row=0, column=0, padx=10, pady=10)

x0, y0, x1, y1 = 5, 5, 35, 35
canvas_boton_redondo.create_oval(x0, y0, x1, y1, fill="#41066f", outline="")
canvas_boton_redondo.create_text(20, 20, text="☆", font=("Arial", 16, "bold"), fill="#b19cd9")
canvas_boton_redondo.tag_bind("all", "<Button-1>", lambda event: mostrar_mensaje()) #Asociamos el evento de click al botón redondo

label_instruccion = tk.Label(frame_central, text="¡Carga los datos antes de comenzar a graficar!", font=("Times New Roman", 20), bg="#b19cd9")
label_instruccion.grid(row=0, column=1, padx=10, pady=10, sticky="w")


button_cargar = tk.Button(frame_central, text="Cargar Datos", command=iniciar_descarga, width=15, height=2, font=("Times New Roman", 12, "bold"), bg="#9d55cd", foreground="black",
                          activeforeground="black", activebackground="#7000a2")
button_cargar.grid(row=1, column=0, columnspan=2, pady=20)

label_status = tk.Label(frame_central, text="", font=("Times New Roman", 14), bg="black")
label_status.grid(row=2, column=0, columnspan=2, pady=20)

#Creamos un frame para el botón "Start"
frame_boton = tk.Frame(frame_principal, bg="black", bd=0)
frame_boton.grid(row=1, column=0, sticky="ew")
frame_boton.grid_columnconfigure(0, weight=1)

button_start = tk.Button(frame_boton, text="Start", width=10, height=2, font=("Times New Roman", 12, "bold"), bg="#74D153", fg= "black", activebackground="#1c7323", foreground="black", command=mostrar_pantalla_secundaria)
button_start.grid(row=0, column=0, pady=10)

#Inicializamos una función para aplicar fondos a las pantallas deseadas
def aplicar_fondo(frame, ruta_imagen):
    """Función que aplica un fondo de una imagen específica a las pantallas.

    Args:
        frame (Tkinter Object): Frame de la pantalla a la que se le aplicará el fondo.
        ruta_imagen (directorio): Ruta de la imagen que se aplicará como fondo.

    Returns:
        None
    """
    imagen = Image.open(ruta_imagen)
    canvas = tk.Canvas(frame, bg="black", highlightthickness=0)
    canvas.place(relwidth=1, relheight=1)

    frame.grid_rowconfigure(0, weight=1)
    frame.grid_columnconfigure(0, weight=1)

    def ajustar_imagen(event=None):
        nuevo_ancho = canvas.winfo_width()
        nuevo_alto = canvas.winfo_height()

        imagen_redimensionada = imagen.resize((nuevo_ancho, nuevo_alto), Image.LANCZOS)
        bg_image = ImageTk.PhotoImage(imagen_redimensionada)

        canvas.delete("all")
        canvas.create_image(0, 0, image=bg_image, anchor="nw")
        canvas.bg_image = bg_image
    canvas.bind("<Configure>", ajustar_imagen)
    ajustar_imagen()

#Creamos un frame secundario para contener los elementos secundarios
frame_secundario = tk.Frame(root, bg="black")
aplicar_fondo(frame_secundario, ruta_imagen)

frame_secundario.grid_rowconfigure(0, weight=0, pad=20)
frame_secundario.grid_rowconfigure(1, weight=0, pad=40)
frame_secundario.grid_rowconfigure(2, weight=1)
for i in range(5):
    frame_secundario.grid_columnconfigure(i, weight=1)

#Definimos el botón para retroceder a la pantalla anterior
button_back_secundario = tk.Button(frame_secundario, text="<", command=mostrar_pantalla_principal, width=3, height=2, font=("Times New Roman", 10, "bold"), bg="#5c168d", fg="white", activebackground="#5c168d")
button_back_secundario.grid(row=0, column=0, sticky='w', padx=10, pady=10)

#Definimos los botones que nos permiten ir a la pantalla perteneciente a cada gráfico
button_scatter = tk.Button(frame_secundario, text="Scatter Plot", command=lambda: mostrar_pantalla_scatter(), width=22, height=2, font=("Times New Roman", 12, "bold"), bg="#9d55cd", fg="white", activebackground="#5c168d")
button_scatter.grid(row=1, column=0, padx=10, pady=30, sticky='ew')

button_hr = tk.Button(frame_secundario, text="Diagrama HR", command=lambda: mostrar_pantalla_diagrama(), width=22, height=2, font=("Times New Roman", 12, "bold"), bg="#9d55cd", fg="white", activebackground="#5c168d")
button_hr.grid(row=1, column=1, padx=10, pady=30, sticky='ew')

button_histogram = tk.Button(frame_secundario, text="Histogramas", command=lambda: mostrar_pantalla_histograma(), width=22, height=2, font=("Times New Roman", 12, "bold"), bg="#9d55cd", fg="white", activebackground="#5c168d")
button_histogram.grid(row=1, column=2, padx=10, pady=30, sticky='ew')

button_simulations = tk.Button(frame_secundario, text="Simulaciones de Órbitas", command=lambda: mostrar_pantalla_orbita(), width=22, height=2, font=("Times New Roman", 12, "bold"), bg="#9d55cd", fg="white", activebackground="#5c168d")
button_simulations.grid(row=1, column=3, padx=10, pady=30, sticky='ew')

button_maps = tk.Button(frame_secundario, text="Mapas de Temperatura", command=lambda: mostrar_pantalla_mapa(), width=22, height=2, font=("Times New Roman", 12, "bold"), bg="#9d55cd", fg="white", activebackground="#5c168d")
button_maps.grid(row=1, column=4, padx=10, pady=30, sticky='ew')

#Definimos las etiquetas que describen cada gráfico
font_size = 12 #Fuente de letra estándar

label_scatter = tk.Label(frame_secundario, text="Un scatter plot o diagrama de dispersión es un gráfico que muestra la relación entre dos variables diferentes. Cada punto en el gráfico representa un par de valores, uno en el eje horizontal y otro en el eje vertical. Se usa para observar cómo se relacionan o correlacionan estas dos variables. Por ejemplo, podrías usar un scatter plot para ver si hay una relación entre la temperatura y el brillo de diferentes estrellas.", wraplength=170, bg="#b19cd9", fg="black", font=("Times New Roman", font_size))
label_scatter.grid(row=2, column=0, padx=10, pady=5, sticky='ew')

label_hr = tk.Label(frame_secundario, text="El diagrama HR es un gráfico que muestra la relación entre la luminosidad (o brillo) de las estrellas y su temperatura superficial. En este gráfico, la temperatura se coloca en el eje horizontal (de mayor a menor), y la luminosidad en el eje vertical. Este diagrama ayuda a clasificar las estrellas en diferentes tipos, como enanas, gigantes y supergigantes, y a entender su evolución a lo largo del tiempo.", wraplength=170, bg="#b19cd9", fg="black", font=("Times New Roman", font_size))
label_hr.grid(row=2, column=1, padx=10, pady=5, sticky='ew')

label_histogram = tk.Label(frame_secundario, text="Un histograma es un tipo de gráfico que muestra la distribución de un conjunto de datos. Los datos se dividen en intervalos o 'bins', y se cuenta cuántas veces ocurren valores en cada intervalo. Esto permite visualizar cómo se distribuyen los datos, por ejemplo, cómo se distribuyen las temperaturas de un grupo de exoplanetas.", wraplength=170, bg="#b19cd9", fg="black", font=("Times New Roman", font_size))
label_histogram.grid(row=2, column=2, padx=10, pady=5, sticky='ew')

label_simulations = tk.Label(frame_secundario, text="La simulación de órbitas es una herramienta que modela el movimiento de cuerpos celestes, como planetas o satélites, alrededor de un objeto central (como una estrella). Utiliza las leyes de la física para predecir y mostrar cómo cambian las órbitas con el tiempo. Esto es útil para entender la dinámica de los sistemas planetarios y prever eventos futuros.", wraplength=170, bg="#b19cd9", fg="black", font=("Times New Roman", font_size))
label_simulations.grid(row=2, column=3, padx=10, pady=5, sticky='ew')

label_maps = tk.Label(frame_secundario, text="Un mapa de temperatura es una representación gráfica que muestra la distribución de temperaturas en una superficie o área específica. En astronomía, se usa para visualizar cómo varía la temperatura en la superficie de un planeta o estrella. Estos mapas ayudan a identificar patrones y variaciones térmicas que pueden influir en el ambiente y las condiciones de esos cuerpos celestes.", wraplength=170, bg="#b19cd9", fg="black", font=("Times New Roman", font_size))
label_maps.grid(row=2, column=4, padx=10, pady=5, sticky='ew')


#Siguiente sección; Creación y manejo de las pantallas secundarias

#Definimos primeramente un diccionario con los nombres de los parámetros en español y su correspondiente en inglés
param_map_es_to_en = {
    "Distancia angular": "angular_distance",
    "Argumento del periastrón": "omega",
    "Temperatura calculada": "temp_calculated",
    "Fecha de conjunción": "tconj",
    "Época del Periastrón": "tperi",
    "Albedo geométrico": "geometric_albedo",
    "Longitud del punto más caliente": "hot_point_lon",
    "Parámetro de impacto b": "impact_parameter",
    "Temperatura medida": "temp_measured",
    "Excentricidad orbital": "eccentricity",
    "Inclinación orbital": "inclination",
    "Período orbital": "orbital_period",
    "Masa planetaria": "mass",
    "Masa planetaria*sin(i)": "mass_sini",
    "Radio planetario": "radius",
    "Tránsito primario": "tzero_tr",
    "Tránsito secundario": "tzero_tr_sec",
    "Semieje mayor": "semi_major_axis",
    "Ángulo proyectado en el cielo entre el giro orbital planetario y el giro estelar": "lambda_angle",
    "Velocidad Semiamplitud K": "k",
    "Año de descubrimiento": "discovered",
    "Cero Tiempo de velocidad radial": "tzero_vr",
    "Log(g)": "log_g",
    "Edad de la estrella anfitriona": "star_age",
    "Dec (J2000) de una estrella": "dec",
    "Distancia a la estrella anfitriona": "star_distance",
    "Temperatura efectiva de la estrella anfitriona": "star_teff",
    "Magnitud H de la estrella anfitriona": "mag_h",
    "Magnitud I de la estrella anfitriona": "mag_i",
    "Magnitud J de la estrella anfitriona": "mag_j",
    "Metalidad de la estrella anfitriona": "star_metallicity",
    "Magnitud R de la estrella anfitriona": "mag_r",
    "Ascensión recta (J2000) de una estrella": "ra",
    "Radio de la estrella anfitriona": "star_radius",
    "Magnitud V de la estrella anfitriona": "mag_v",
    "Masa de la estrella anfitriona": "star_mass",
}


#Definimos una función para cargar los nombres de las estrellas en el Combobox del Scatter Plot
def star_names_scatter():
    """Función para cargar los nombres de las estrellas en el Combobox del Scatter Plot.
    """
    global combo_box_estrellas_scatter, combo_box_parametro_scatter, datos

    if datos is not None and 'star_name' in datos.columns:
        star_names = datos['star_name'].dropna().unique().tolist()
        combo_box_estrellas_scatter['values'] = star_names
        print(f"Se han cargado {len(star_names)} nombres de estrellas en el Combobox de Scatter Plot")
    else:
        print("Error: No se pueden cargar los nombres de las estrellas para el Scatter Plot")

    def on_combobox_keyrelease(event):
        typed_text = combo_box_estrellas_scatter.get().lower()
        filtered_values = [name for name in star_names if typed_text in name.lower()]
        filtered_values.sort(key=lambda x: (x.lower().find(typed_text), len(x)))
        combo_box_estrellas_scatter['values'] = filtered_values
        combo_box_estrellas_scatter.event_generate('<Down>')

    combo_box_estrellas_scatter.bind('<KeyRelease>', on_combobox_keyrelease)
    print("Función star_names_scatter() ejecutada")

def crear_scatter():
    """Función para crear el gráfico Scatter Plot en una ventana emergente.
    """
    star_name = combo_box_estrellas_scatter.get()
    parametro = combo_box_parametro_scatter.get()
    if star_name and parametro:
        valor_parametro = param_map_es_to_en.get(parametro)
        data_star = datos[datos['star_name'] == star_name]
        
        if not data_star.empty:
            if valor_parametro in data_star.columns:
                if not data_star[valor_parametro].isnull().all():
                    fig, ax = plt.subplots()
                    ax.scatter(data_star['star_name'], data_star[valor_parametro])
                    ax.set_xlabel('Estrella')
                    ax.set_ylabel(parametro)
                    ax.set_title(f'Gráfico Scatter de {star_name} - {parametro}')
                    plt.show()
                else:
                    messagebox.showerror("Error", f"No se encontraron datos para el parámetro '{parametro}'.")
            else:
                messagebox.showerror("Error", f"El parámetro '{parametro}' no está disponible.")
        else:
            messagebox.showerror("Error", "No hay datos disponibles para esta estrella y parámetro.")
    else:
        messagebox.showerror("Error", "Por favor, selecciona una estrella y un parámetro.")


#Creamos un frame para el gráfico Scatter Plot
frame_scatter = tk.Frame(root, bg="black")
aplicar_fondo(frame_scatter, ruta_imagen) #Aplicamos el fondo de pantalla al frame

frame_buttons_left = tk.Frame(frame_scatter, bg="black")

#Ajuste de las filas y columnas del frame
frame_scatter.grid_rowconfigure(0, weight=0)
frame_scatter.grid_rowconfigure(1, weight=0)
frame_scatter.grid_rowconfigure(2, weight=0)
frame_scatter.grid_rowconfigure(3, weight=0)
frame_scatter.grid_rowconfigure(4, weight=0)
frame_scatter.grid_rowconfigure(7, weight=0)
frame_scatter.grid_rowconfigure(6, weight=0)
frame_scatter.grid_rowconfigure(7, weight=1)
frame_scatter.grid_rowconfigure(8, weight=0)
frame_scatter.grid_columnconfigure(0, weight=1)
frame_scatter.grid_columnconfigure(1, weight=0)
frame_scatter.grid_columnconfigure(2, weight=0)
frame_scatter.grid_columnconfigure(3, weight=1)

frame_buttons_left.grid(row=7, column=2, rowspan=2, sticky='ns')

#Definimos el botón de retroceso para poder volver al menú principal
button_back_scatter = tk.Button(frame_scatter, text="<", command=mostrar_pantalla_secundaria, width=2, height=2, font=("Times New Roman", 12, "bold"), bg="#5c168d", fg="white")
button_back_scatter.grid(row=0, column=0, sticky='nw', padx=10, pady=10)

label_scatter = tk.Label(frame_scatter, text="Scatter Plot", font=("Times New Roman", 25), bg="#5c168d")
label_scatter.grid(row=1, column=0, pady=60, padx=23 , sticky='ne')

#Definimos el Combobox para el eje X
label_x = ttk.Label(frame_scatter, text="Seleccione el parámetro para el eje X:", font=("Times New Roman", 14))
label_x.grid(row=2, column=0, pady=10, padx=80, sticky='w')
combobox_x = ttk.Combobox(frame_scatter, values=list(param_map_es_to_en.keys()))
combobox_x.grid(row=3, column=0, pady=10, padx=80, sticky='w')

#Definimos el Combobox para el eje Y
label_y = ttk.Label(frame_scatter, text="Seleccione el parámetro para el eje Y:", font=("Times New Roman", 14))
label_y.grid(row=4, column=0, pady=10, padx=80, sticky='w')
combobox_y = ttk.Combobox(frame_scatter, values=list(param_map_es_to_en.keys()))
combobox_y.grid(row=5, column=0, pady=10, padx=80, sticky='w')

#Definimos el Combobox para el color
label_color = ttk.Label(frame_scatter, text="Seleccione el parámetro para el color:", font=("Times New Roman", 14))
label_color.grid(row=6, column=0, pady=10, padx=80, sticky='w')
combobox_color = ttk.Combobox(frame_scatter, values=list(param_map_es_to_en.keys()))
combobox_color.grid(row=7, column=0, pady=10, padx=80, sticky='w')

var_mostrar_temperatura = tk.IntVar()

plot_button = tk.Button(frame_scatter, text="Graficar", command=on_plot_scatter, width=15, height=2, font=("Times New Roman", 12, "bold"), bg="#74D153", fg="black", activebackground="#1c7323", foreground="black")
plot_button.grid(row=8, column=0, pady=50, padx=80, sticky='w')

combo_box_estrellas_scatter = ttk.Combobox(frame_scatter, font=("Times", 14))
combo_box_parametro_scatter = ttk.Combobox(frame_scatter, values=list(param_map_es_to_en.keys()), font=("Times", 14))

label_seleccionar_estrella = ttk.Label(frame_scatter, text="Seleccione la estrella anfitriona:", font=("Times", 14))
label_seleccionar_estrella.grid(row=2, column=2, pady=10, padx=10, sticky='w')

combo_box_estrellas_scatter.grid(row=3, column=2, pady=10, padx=10, sticky='ew')

label_seleccionar_parametro = ttk.Label(frame_scatter, text="Seleccione otro parámetro:", font=("Times", 14))
label_seleccionar_parametro.grid(row=4, column=2, pady=10, padx=10, sticky='w')

combo_box_parametro_scatter.grid(row=5, column=2, pady=10, padx=10, sticky='ew')

boton_crear_scatter = tk.Button(frame_scatter, text="Crear Gráfica", command=crear_scatter, 
                               width=15, height=2, font=("Times New Roman", 12, "bold"), 
                               bg="#74D153", fg="black", activebackground="#1c7323", foreground="black")
boton_crear_scatter.grid(row=6, column=2, pady=20, padx=10, sticky='ew')

#Este botón nos permite actualizar los valores de las estrellas en el Combobox
boton_actualizar_estrellas_scatter = tk.Button(frame_scatter, text="Actualizar lista de estrellas", command=star_names_scatter)
boton_actualizar_estrellas_scatter.grid(row=7, column=2, pady=10, padx=10, sticky='ew')

frame_buttons_left.grid(row=7, column=3, rowspan=2, sticky='ns')

#Definimos una función para aplicar el fondo de manera similar, pero con una imagen distinta
def aplicar_fondo_hr(frame, ruta_imagen):
    """Función que aplica el fondo de una imagen específica al frame del Diagrama#Este botón nos permite actualizar los valores de las estrellas en el Combobox H-R.

    Args:
        frame (Tkinter Object): Frame del gráfico Diagrama H-R.
        ruta_imagen (directorio): Ruta de la imagen que se aplicará como fondo.
    """
    imagen_2 = Image.open(ruta_imagen)

    canvas = tk.Canvas(frame, bg="black", highlightthickness=0)
    canvas.place(relwidth=1, relheight=1)

    frame.grid_rowconfigure(0, weight=1)
    frame.grid_columnconfigure(0, weight=1)

    def ajustar_imagen(event=None):
        nuevo_ancho = canvas.winfo_width()
        nuevo_alto = canvas.winfo_height()

        if nuevo_ancho <= 0 or nuevo_alto <= 0:
            return
        imagen_redimensionada = imagen_2.resize((nuevo_ancho, nuevo_alto), Image.LANCZOS)
        bg_image = ImageTk.PhotoImage(imagen_redimensionada)

        canvas.delete("all")
        canvas.create_image(0, 0, image=bg_image, anchor="nw")
        canvas.bg_image = bg_image

    canvas.bind("<Configure>", ajustar_imagen)
    ajustar_imagen()

ruta_imagen_diagrama = os.path.join(directorio_actual, "diagrama_hr_fondo.png")

#Creamos el frame para el gráfico Diagrama H-R
frame_diagrama = tk.Frame(root, bg="black")
aplicar_fondo_hr(frame_diagrama, ruta_imagen_diagrama)

frame_diagrama.grid(row=0, column=0, sticky="nsew")
frame_diagrama.grid_forget()

frame_diagrama.grid_rowconfigure(0, weight=0)
frame_diagrama.grid_rowconfigure(1, weight=0)
frame_diagrama.grid_rowconfigure(2, weight=1)
frame_diagrama.grid_columnconfigure(0, weight=1)

#Definimos el botón de retroceso para poder volver al menú principal
button_back_diagrama = tk.Button(frame_diagrama, text="<", command=mostrar_pantalla_secundaria, width=2, height=2, font=("Times New Roman", 12, "bold"), bg="#5c168d", fg="white")
button_back_diagrama.grid(row=0, column=0, sticky='nw', padx=10, pady=10)

label_diagrama = tk.Label(frame_diagrama, text="Diagrama Hertzsprung-Russell", font=("Times New Roman",25), bg="#5c168d")
label_diagrama.grid(row=1, column=0, pady=60, sticky='n')

plot_button = tk.Button(frame_diagrama, text="Graficar", command=plot_diagrama_hr, width=15, height=2, font=("Times New Roman", 12, "bold"), bg="#74D153", fg= "black", activebackground="#1c7323", foreground="black")
plot_button.grid(row=1, column=0, pady=150)


#Definimos una función para cargar los nombres de las estrellas en el Combobox del Scatter Plot
def star_names_hist():
    """Función para cargar los nombres de las estrellas en el Combobox del gráfico Histograma.
    """
    global combo_box_estrellas_hist, combo_box_parametro_hist, datos
    
    if datos is not None and 'star_name' in datos.columns:
        star_names = datos['star_name'].dropna().unique().tolist()
        combo_box_estrellas_hist['values'] = star_names
        print(f"Se han cargado {len(star_names)} nombres de estrellas en el Combobox")
    else:
        print("Error: No se pueden cargar los nombres de las estrellas")

    def on_combobox_keyrelease_hist(event):
        typed_text = combo_box_estrellas_hist.get().lower()
        filtered_values = [name for name in star_names if typed_text in name.lower()]
        filtered_values.sort(key=lambda x: (x.lower().find(typed_text), len(x)))
        combo_box_estrellas_hist['values'] = filtered_values
        combo_box_estrellas_hist.event_generate('<Down>')

    combo_box_estrellas_hist.bind('<KeyRelease>', on_combobox_keyrelease_hist)

def crear_histograma():
    """Función para crear el gráfico Histograma en una ventana emergente.
    """
    star_name = combo_box_estrellas_hist.get()
    parametro = combo_box_parametro_hist.get()
    if star_name and parametro:
        valor_parametro = param_map_es_to_en.get(parametro)
        data_star = datos[datos['star_name'] == star_name]
        
        if not data_star.empty:
            if valor_parametro in data_star.columns:
                if not data_star[valor_parametro].isnull().all():
                    fig, ax = plt.subplots()
                    ax.hist(data_star[valor_parametro], bins=10, alpha=0.75, color='blue')
                    ax.set_xlabel(parametro)
                    ax.set_ylabel('Frecuencia')
                    ax.set_title(f'Histograma de {parametro} para {star_name}')
                    plt.show()
                else:
                    messagebox.showerror("Error", f"No se encontraron datos para el parámetro '{parametro}'.")
            else:
                messagebox.showerror("Error", f"El parámetro '{parametro}' no está disponible.")
        else:
            messagebox.showerror("Error", "No hay datos disponibles para esta estrella y parámetro.")
    else:
        messagebox.showerror("Error", "Por favor, selecciona una estrella y un parámetro.")


#Creamos un frame para el gráfico Histograma
frame_hist = tk.Frame(root, bg="black")
aplicar_fondo(frame_hist, ruta_imagen)

frame_hist.grid_rowconfigure(0, weight=0)
frame_hist.grid_rowconfigure(1, weight=0)
frame_hist.grid_rowconfigure(2, weight=0)
frame_hist.grid_rowconfigure(3, weight=0)
frame_hist.grid_rowconfigure(4, weight=0)
frame_hist.grid_columnconfigure(0, weight=1)
frame_hist.grid_columnconfigure(1, weight=1)

#Definimos el botón de retroceso para poder volver al menú principal
button_back_hist = tk.Button(frame_hist, text="<", command=mostrar_pantalla_secundaria, width=2, height=2, font=("Times New Roman", 12, "bold"), bg="#5c168d", fg="white")
button_back_hist.grid(row=0, column=0, sticky='nw', padx=10, pady=10)

label_hist = tk.Label(frame_hist, text="Histograma", font=("Times New Roman", 25), bg="#5c168d")
label_hist.grid(row=1, column=0, pady=60, padx=150, sticky='n', columnspan=2)  # Centrar la etiqueta en ambas columnas

tipo_hist = ["Estrellas", "Exoplanetas"]
label_tipo_hist = ttk.Label(frame_hist, text="Seleccione el tipo de histograma: ", font=("Times New Roman", 16))
label_tipo_hist.grid(row=2, column=0, pady=10, sticky='w', padx=200)

combobox_tipo_hist = ttk.Combobox(frame_hist, values=tipo_hist, width=25, font=("Times New Roman", 16))
combobox_tipo_hist.grid(row=3, column=0, pady=10, padx=200, sticky='w')

label_x_hist = ttk.Label(frame_hist, text="Seleccione el parámetro para el eje X: ", font=("Times New Roman", 16))
label_x_hist.grid(row=4, column=0, pady=10, sticky='w', padx=200)

#Combobox para seleccionar el parámetro
combobox_x_hist = ttk.Combobox(frame_hist, values=list(param_map_es_to_en.keys()), width=25, font=("Times New Roman", 16))
combobox_x_hist.grid(row=5, column=0, pady=10, padx=200, sticky='w')

plot_button_hist = tk.Button(frame_hist, text="Graficar", command=plot_histograma, 
                             width=10, height=2, font=("Times New Roman", 12, "bold"), 
                             bg="#74D153", fg="black", activebackground="#1c7323", foreground="black")
plot_button_hist.grid(row=6, column=0, pady=10, padx=200, sticky='w')

#Este botón nos permite actualizar los valores de las estrellas en el Combobox
boton_actualizar_estrellas = tk.Button(frame_hist, text="Actualizar lista de estrellas", command=star_names_hist)
boton_actualizar_estrellas.grid(row=7, column=1, pady=10, padx=20, sticky='w')

label_seleccion_hist = ttk.Label(frame_hist, text="Seleccione la estrella anfitriona: ", font=("Times New Roman", 16))
label_seleccion_hist.grid(row=2, column=1, pady=10, sticky='w', padx=20)

#Combobox para seleccionar la estrella
combo_box_estrellas_hist = ttk.Combobox(frame_hist, font=("Times New Roman", 14), width=16)
combo_box_estrellas_hist.grid(row=3, column=1, pady=10, padx=20, sticky='w')

label_seleccion_hist = ttk.Label(frame_hist, text="Seleccione el parámetro: ", font=("Times New Roman", 16))
label_seleccion_hist.grid(row=4, column=1, pady=10, sticky='w', padx=20)  # Cambié row a 1

#Combobox para seleccionar el parámetro
combo_box_parametro_hist = ttk.Combobox(frame_hist, values=list(param_map_es_to_en.keys()), font=("Times New Roman", 16), width=16)
combo_box_parametro_hist.grid(row=5, column=1, pady=10, padx=20, sticky='w')

boton_crear_histograma = tk.Button(frame_hist, text="Crear Histograma", command=crear_histograma, 
                             width=15, height=2, font=("Times New Roman", 12, "bold"), 
                             bg="#74D153", fg="black", activebackground="#1c7323", foreground="black")
boton_crear_histograma.grid(row=6, column=1, pady=10, padx=20, sticky='w')


#Creamos el frame para el gráfico Simulación de Órbitas
frame_orb = tk.Frame(root, bg="black")
aplicar_fondo(frame_orb, ruta_imagen)

frame_orb.grid_rowconfigure(0, weight=0)
frame_orb.grid_rowconfigure(1, weight=0)
frame_orb.grid_rowconfigure(2, weight=0)
frame_orb.grid_rowconfigure(3, weight=0)
frame_orb.grid_rowconfigure(4, weight=0)
frame_orb.grid_rowconfigure(5, weight=0)
frame_orb.grid_columnconfigure(0, weight=1)
frame_orb.grid_columnconfigure(0, weight=1)
frame_orb.grid_columnconfigure(2, weight=1)

#Definimos el botón de retroceso para poder volver al menú principal
button_back_orbit = tk.Button(frame_orb, text="<", command=mostrar_pantalla_secundaria, width=2, height=2, font=("Times New Roman", 12, "bold"), bg="#5c168d", fg="white")
button_back_orbit.grid(row=0, column=0, sticky='nw', padx=10, pady=10)

Sub_titulo = tk.Label(frame_orb, text="Simulación de órbitas", background="#5c168d", font=("Times", 25))
Sub_titulo.grid(row=1, column=1, pady=50, padx=10, sticky='n')  # Aumentar pady para bajar

Pregunta_usuario = tk.Label(frame_orb, text="¿Qué sistema quieres graficar?", background="#b19cd9", font=("Times", 16))
Pregunta_usuario.grid(row=2, column=1, pady=10, padx=10, sticky='n')

Boton_planetario = tk.Button(frame_orb, text="Sistemas Planetarios", command=mostrar_sistemas_planetarios, font=("Times", 14))
Boton_planetario.grid(row=3, column=1, pady=20, padx=10, sticky='n')

combo_box_estrellas = ttk.Combobox(frame_orb, font=("Times", 20))
combo_box_estrellas.grid(row=4, column=1, pady=10, padx=10, sticky='n')

Graficar_sistema = tk.Button(frame_orb, text="Graficar", command=graficar_orbitas, 
                             width=10, height=2, font=("Times New Roman", 12, "bold"), 
                             bg="#74D153", fg="black", activebackground="#1c7323", foreground="black")
Graficar_sistema.grid(row=5, column=1, pady=70, padx=10, sticky='n')


#Creamos el frame para el gráfico Mapa de Temperatura
frame_mapa = tk.Frame(root, bg="black")
aplicar_fondo(frame_mapa, ruta_imagen)

frame_mapa.grid_rowconfigure(0, weight=0)
frame_mapa.grid_rowconfigure(1, weight=0)
frame_mapa.grid_rowconfigure(2, weight=0)
frame_mapa.grid_rowconfigure(3, weight=0)
frame_mapa.grid_columnconfigure(0, weight=1)

#Definimos el botón de retroceso para poder volver al menú principal
button_back_mapa = tk.Button(frame_mapa, text="<", command=mostrar_pantalla_secundaria, width=2, height=2, font=("Times New Roman", 12, "bold"), bg="#5c168d", fg="white")
button_back_mapa.grid(row=0, column=0, sticky='nw', padx=10, pady=10)

label_mapa = tk.Label(frame_mapa, text="Mapas de Temperatura", font=("Times New Roman", 25), bg="#5c168d")
label_mapa.grid(row=6, column=0, pady=60, padx=10)

plot_button_mapa_estrella = tk.Button(frame_mapa, text="Graficar Mapa de Estrellas", command=plot_mapa_estrella, width=25, height=2, font=("Times New Roman", 12, "bold"), bg="#74D153", fg= "black", activebackground="#1c7323", foreground="black")
plot_button_mapa_estrella.grid(row=7, column=0, pady=10, padx=10)

plot_button_mapa_planeta = tk.Button(frame_mapa, text="Graficar Mapa de Exoplanetas", command=plot_mapa_planeta, width=25, height=2, font=("Times New Roman", 12, "bold"), bg="#74D153", fg= "black", activebackground="#1c7323", foreground="black")
plot_button_mapa_planeta.grid(row=8, column=0, pady=20, padx=10)


#Siguiente sección; Detalles de la interfaz gráfica

#Definimos una función para mostrar una ventana emergente con un video tutorial de la interfaz
def mostrar_video():
    """Función para mostrar un video tutorial sobre la interfaz de Exoplanetarium en una ventana emergente.
    """
    ventana_video = Toplevel(root)
    ventana_video.title("Tutorial Exoplanetarium")
    ventana_video.geometry("800x480")
    ventana_video.resizable(False, False)

    canvas_video = tk.Canvas(ventana_video, bg="black")
    canvas_video.pack(fill="both", expand=True)

    script_dir = Path(__file__).resolve().parent
    video_path = script_dir / "Exoplanetarium_Tutorial2.mp4"

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        print("Error: No se pudo abrir el video.")
        return

    def actualizar_frame():
        """Función para actualizar el frame del video en el canvas.
        """
        ret, frame = cap.read()
        if ret:
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            imagen_pillow = Image.fromarray(frame_rgb)
            imagen_tk = ImageTk.PhotoImage(imagen_pillow)

            canvas_video.create_image(0, 0, image=imagen_tk, anchor="nw")
            canvas_video.image = imagen_tk 

            ventana_video.after(30, actualizar_frame)
        else:
            cap.release()
    actualizar_frame()

#Creamos un botón circular en la esquina superior derecha de la ventana principal
canvas_boton_circular = tk.Canvas(frame_principal, width=40, height=40, bg="black", highlightthickness=0)
canvas_boton_circular.place(relx=1.0, rely=0.0, anchor='ne')  # Posición en la esquina superior derecha

x0, y0, x1, y1 = 5, 5, 35, 35  # Coordenadas del círculo
boton_circular = canvas_boton_circular.create_oval(x0, y0, x1, y1, fill="gray", outline="")  # Color del botón

canvas_boton_circular.create_text(20, 20, text="i", font=("Arial", 16, "bold"), fill="black")

def accion_boton_circular(event):
    """Función que permite que, una vez el usuario hace click en el botón circular, se muestre un video tutorial de la interfaz.

    Args:
        event (Tkinter Object): Evento de click en el botón circular.
    """
    mostrar_video()
canvas_boton_circular.tag_bind(boton_circular, "<Button-1>", accion_boton_circular)

root.mainloop()